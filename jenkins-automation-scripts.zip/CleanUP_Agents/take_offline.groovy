import java.util.*;
import hudson.slaves.*;
import static com.cloudbees.opscenter.server.persistence.SlaveLeaseTable.getLeases;

boolean busy = true;

def isBusy(sAgent) {
    def online = sAgent.getOfflineCause() == null;
    if (online) {
        def leases = getLeases(sAgent.getUid());
        busy = leases != null && !leases.isEmpty();
        if (busy) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
};

boolean offline = false;

if (agent_name == null) {
  println "The name of the agent was not passed";
} else {
    Jenkins.instance.allItems.grep {
        it.class.name == 'com.cloudbees.opscenter.server.model.SharedSlave' && it.name == agent_name;
    }.each {
        busy = isBusy(it);
        if (busy) {
            offline = false;
        } else {
            it.doDisable();
            offline = true;
        }
    }
};
   
return offline;
