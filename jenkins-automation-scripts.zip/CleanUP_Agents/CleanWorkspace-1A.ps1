# WinAgent1 - RR SVRP00086ED4
# Location - C:\DPT_Scripts

$win_svc_name = "WindowsBuildAgent-1A"
$agent_home = "V:\jenkins\WindowsBuildAgent-1A"
$volume = "'V:'"

.\CleanWorkspace.ps1 $win_svc_name $agent_home $volume
