$uri = 'https://jenkins-oc.ups.com:8443/scriptText'
$agent_name = $args[0]
$groovy_script = "agent_name = '$agent_name';"
$groovy_script += Get-Content -Path take_online.groovy

$user = 'jenkinsplssvc'
$pass = '11f8168684a2e930ac7929c29851e08a45'
$pair = "$($user):$($pass)"
$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
$basicAuthValue = "Basic $encodedCreds"

$headers = @{
    Authorization = $basicAuthValue
}


$body = @{
    'script' = "$groovy_script"
}

Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $body
