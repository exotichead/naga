if (agent_name == null) {
  println "The name of the agent was not passed";
} else {
    Jenkins.instance.allItems.grep {
        it.class.name == 'com.cloudbees.opscenter.server.model.SharedSlave' && it.name == agent_name;
    }.each {
        it.doEnable();
    }
};

return 0;
