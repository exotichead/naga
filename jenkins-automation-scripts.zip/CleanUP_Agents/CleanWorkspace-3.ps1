# WinAgent3 - WW SVRP00082961
# Location - C:\DPT_Scripts

$win_svc_name = "WindowsBuildAgent-3"
$agent_home = "C:\Program Files\jenkins"
$volume = "'C:'"

.\CleanWorkspace.ps1 $win_svc_name $agent_home $volume
