# This scripts sends a Windows Driver space report.
$dl = @('mernesto@ups.com','monilpatel@ups.com','kbutryn@ups.com','sdumortier@ups.com')
$name = hostname 

function Get-DiskInfo {
    [CmdletBinding()]
    param ([string]$DeviceID)  # Value should be a String enclosed in single quotes and with a ":" at the end, E.g.  'V:'
    # Get Disk Usage
    $disk = Get-WmiObject Win32_LogicalDisk -ComputerName localhost -Filter "DeviceID=$DeviceID" | Select-Object Size,FreeSpace
    Write-Output "$DeviceID`n------------------------------"  | Out-File -Append -FilePath .\Report.txt
    $size = [math]::round($disk.Size / 1024 / 1024 / 1024, 2)
    $freespace = [math]::round($disk.FreeSpace / 1024 / 1024 / 1024, 2)
    $usedspace = [math]::round(($disk.Size - $disk.FreeSpace) / 1024 / 1024 / 1024, 2)
    Write-Output "Disk Size:      $size GB"       | Out-File -Append -FilePath .\Report.txt
    Write-Output "Disk FreeSpace: $freespace GB"  | Out-File -Append -FilePath .\Report.txt
    Write-Output "Disk Used:      $usedspace GB"  | Out-File -Append -FilePath .\Report.txt
    Write-Output "`n"  | Out-File -Append -FilePath .\Report.txt
}

function Send-Email {
    [CmdletBinding()]
    param (
        [string]$Sender, # Email address 
        [string]$Agent # Email address 
    )  
    $message = Get-Content -Path .\Report.txt | out-string
    $message 
    Send-MailMessage -From $Sender -To $dl -Subject "Weekly Space Report - $Agent" -SmtpServer "smtpapps.ups.com" -Body "$message"
}

switch ($name)
{
    "SVRP00086ED4" {
        Write-Output "Agent1 - $name `n" | Out-File -FilePath .\Report.txt
        Get-DiskInfo -DeviceID "'V:'"  # Agents 1A and 1AC share V: drive
        Get-DiskInfo -DeviceID "'W:'"  # Agent 1AB
        Get-DiskInfo -DeviceID "'D:'"  # Agent 1AD
        Send-Email -Sender "WinSharedAgent1@ups.com" -Agent "Agent1"
        Break
    }
    "SVRP00082963" {
        Write-Output "Agent2 - $name `n" | Out-File -FilePath .\Report.txt
        Get-DiskInfo -DeviceID "'D:'"  # Agent 2
        Get-DiskInfo -DeviceID "'C:'"  # Agent 2A
        Send-Email -Sender "WinSharedAgent2@ups.com" -Agent "Agent2"
        Break
    }
    "SVRP00082961" {
        Write-Output "Agent3 - $name `n" | Out-File -FilePath .\Report.txt 
        Get-DiskInfo -DeviceID "'C:'"  # Agent 3
        Get-DiskInfo -DeviceID "'D:'"  # Agents 3A & 3D share the D: Drive
        Send-Email -Sender "WinSharedAgent3@ups.com" -Agent "Agent3"
        Break
    }
    Default {
        "No matches"
    }
}
