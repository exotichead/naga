# WinAgent2 - WW SVRP00082963
# Location - C:\DPT_Scripts

$win_svc_name = "WindowsBuildAgent-2A"
$agent_home = "C:\jenkins-agent\WindowsBuildAgent-2A"
$volume = "'C:'"

.\CleanWorkspace.ps1 $win_svc_name $agent_home $volume
