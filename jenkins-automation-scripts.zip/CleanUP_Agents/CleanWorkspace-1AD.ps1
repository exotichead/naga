# WinAgent1 - RR SVRP00086ED4
# Location - C:\DPT_Scripts

$win_svc_name = "WindowsBuildAgent-1AD"
$agent_home = "D:\Program Files\jenkins\WindowsBuildAgent-1AD"
$volume = "'D:'"

.\CleanWorkspace.ps1 $win_svc_name $agent_home $volume
