# Make sure the Windows Shared Agent is Offline in the Ops Center
# Location - C:\DPT_Scripts

$win_svc_name = $args[0]    # The service name and the agent name are the same
$agent_home = $args[1]
$volume = $args[2]


$result = .\TakeAgentOffline.ps1 $win_svc_name

if ( $result.Trim() -eq "Result: true" )
{
    Write-Host "The agent is Offline now, begin cleaning the workspace"

    # Get Disk Usage - B4
    $disk = Get-WmiObject Win32_LogicalDisk -ComputerName localhost -Filter "DeviceID=$volume" | Select-Object Size,FreeSpace
    Write-Host "Disk Size: " $disk.Size
    Write-Host "Disk FreeSpace: " $disk.FreeSpace

    # Stop the service
    Write-Host "Stop service: " $win_svc_name
    Stop-Service -Name $win_svc_name

    # Clean the Workspaces 
    Write-Host "Deleting the workspace..."
    Remove-Item -Recurse -Force $agent_home"\*\workspace\*"

    # Start the service
    Write-Host "Start service: " $win_svc_name
    Start-Service -Name $win_svc_name

    # Get Disk Usage - After
    $disk = Get-WmiObject Win32_LogicalDisk -ComputerName localhost -Filter "DeviceID=$volume" | Select-Object Size,FreeSpace
    Write-Host "Disk Size: " $disk.Size
    Write-Host "Disk FreeSpace: " $disk.FreeSpace

    # Bring up the Agent 
    .\TakeAgentOnline.ps1 $win_svc_name

}
else
{
    Write-Host "The agent is Busy, skipping for now"
}
