# WinAgent2 - WW SVRP00082963
# Location - C:\DPT_Scripts

$win_svc_name = "WindowsBuildAgent-2"
$agent_home = "D:\Jenkins"
$volume = "'D:'"

.\CleanWorkspace.ps1 $win_svc_name $agent_home $volume
