/* ***** The following Jenkins items extends the Job Class *****
Freestyle projec            = hudson.model.FreeStyleProject
Maven project               = hudson.maven.MavenModuleSet
Pipeline                    = org.jenkinsci.plugins.workflow.job.WorkflowJob
Backup and restore          = com.infradna.hudson.plugins.backup.BackupProject
External Job                = hudson.model.ExternalJob
Multi-configuration project = hudson.matrix.MatrixProject   (2 items are created)
                            = hudson.matrix.MatrixConfiguration
Ivy project                 = hudson.ivy.IvyModuleSet
Long-Running Project        = com.cloudbees.jenkins.plugins.longrunning.LongRunningProject
***** */

/* ***** The following Jenkins items are not Jobs *****
Multibranch pipeline job    = org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject
GitHub Organization         = jenkins.branch.OrganizationFolder
Bitbucket Team Project      = jenkins.branch.OrganizationFolder
Folder                      = com.cloudbees.hudson.plugins.folder.Folder
Publisher Template          = com.cloudbees.hudson.plugins.modeling.impl.publisher.PublisherTemplate
Job Template                = com.cloudbees.hudson.plugins.modeling.impl.jobTemplate.JobTemplate
Auxiliary Template          = com.cloudbees.hudson.plugins.modeling.impl.auxiliary.AuxModel
Builder Template            = com.cloudbees.hudson.plugins.modeling.impl.builder.BuilderTemplate
Folder Template             = com.cloudbees.hudson.plugins.modeling.impl.folder.FolderTemplate
**** */

println "df /Jenkins_Home".execute().text

// For each Job
for (job in Jenkins.instance.getAllItems(Job.class)) {  // https://javadoc.jenkins.io/hudson/model/Job.html
  if (job.isBuilding()) {
    println(job.getRootDir() + ', currently building, skipping')
  }
  else {
    numbuilds = job.builds.size()
    if (numbuilds == 0) {
        println('No builds -> ' + job.fullName)
    } else {
        println(job.getRootDir())
    }
  }
}

println "df /Jenkins_Home".execute().text

for (job in Jenkins.instance.getAllItems(org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject.class)) { 
  println job
}

/*
https://javadoc.jenkins-ci.org/hudson/model/AbstractBuild.html#getWorkspace--
https://javadoc.jenkins.io/plugin/jobcacher/jenkins/plugins/jobcacher/ArbitraryFileCache.html
// /Jenkins_Home/jenkins/jobs/TTG/jobs/test-agms-utaf-report-generation/branches/feature-ofp-save-to-couchbase
// workspacePath.deleteRecursive()
// job.doDoWipeOutWorkspace()  // -> https://github.com/cloudbees/jenkins-scripts/blob/master/cleanupAgentWorkspacesForSpecificAgents.groovy
// for (job in Jenkins.instance.getAllItems(hudson.model.AbstractProject.class)) {  // Count: 77, mostly freestyle
*/