import groovy.time.TimeCategory;
import groovy.time.TimeDuration;

//Set the Full JOb Path and Promotion Process Name
def fullJobPath = "PLS/autoPromoteTestJob";
def promotionProcessName = "TestPromote";

def now = new Date();
def currentTimestampStr = now.format("yyyy-MM-dd HH:mm:ss z");
Date currentTimestamp = Date.parse("yyyy-MM-dd HH:mm:ss z",currentTimestampStr);
TimeDuration twoHours = new TimeDuration(2, 0, 0, 0);
def buildNumber,buildStatus;
//Parse Through Each Build of the Target Job
def builds = Jenkins.instance.getItemByFullName(fullJobPath).getBuilds();
println "Starting Auto Promotion Process  :"
println "[Config]     Target Job Path : ${fullJobPath}";
println "[Config]     Target Promotion Process : ${promotionProcessName}";
println "[Config]     Current Time : ${currentTimestampStr}";
println "[Config]     Target Promotion Duration : ${twoHours}"
println " ";
println " ";
println "[INFO]       Starting Parse Process for each build";
println " ";
builds.each {
  def p = it.getAction(hudson.plugins.promoted_builds.PromotedBuildAction);
  //Get the build Status, number, build time
  buildStatus = it.getResult().toString();
  buildNumber = it.getNumber().toString();
  getbuildTime = it.getTime();
  formatedDate = getbuildTime.format("yyyy-MM-dd HH:mm:ss z");
  buildTime = Date.parse("yyyy-MM-dd HH:mm:ss z",formatedDate);
  TimeDuration buildDuration = TimeCategory.minus(currentTimestamp, buildTime);
  //If the Build is "Success" & Build is not Promoted
  if ((p && !p.hasPromotion()) && (buildStatus == "SUCCESS") && (buildDuration.compareTo(twoHours) >= 0)) {
      println p
      println "[BUILD-INFO] Build #${buildNumber}  | Result : ${buildStatus}  | buildTime : ${formatedDate} | Current time : ${currentTimestampStr} | Build buildDuration : ${buildDuration.toString()}";
      try {
        //p.doForcePromotion(promotionProcessName);
        println "[Promoted]   Promotion Executed"
        println "                       > Promoted Successfully";
      }
      catch(Exception e) {
        println "[SKIPPED]    Exception: Skipped due to following";
        println "                       > Error While Promoting";
      }
  }
  else{
    println "[SKIPPED]    Build #${buildNumber}  | Result : ${buildStatus}  | buildTime : ${formatedDate} | Current time : ${currentTimestampStr} | Build buildDuration : ${buildDuration.toString()}";
    println "[SKIPPED]    Exception: Skipped due to following";
    if (buildDuration.compareTo(twoHours) < 0) {
      println "                       > Build duration is less then 2 hours";
      println "                       > Duration of the build is ${buildDuration.toString()}";

    }
    else if (buildStatus != "SUCCESS") {
      println "                       > Build Status was not 'SUCCESS'";
      println "                       > Status of the build is ${buildStatus}";
    }
     else if (p && p.hasPromotion() == true) {
      println "                       > Build is already promoted";
    }
    else if (!p) {
      println "                       > Build is not Configured for any promotion";
    }
    else{
      println "                       > Unknown error occured"
    }
  }
  println " ";
}
