#!/bin/bash
# Deployed on OC at -> /Jenkins_Home/pluginsWikiGenerator.sh

echo 'curl'
curl -X POST https://jenkins-m6.ups.com:8443/job/PLS/job/JenkinsWikiPluginVersions/buildWithParameters --user jenkinsplssvc:11f8168684a2e930ac7929c29851e08a45 -d "PLUGINS_JSON=`cat /tmp/plugins.json`"
rm -v /tmp/plugins.json
