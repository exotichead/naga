import com.cloudbees.opscenter.server.model.*
import com.cloudbees.opscenter.server.clusterops.steps.*
import groovy.json.JsonOutput

// This script is meant to be run in the OC Script Console.
def retour = '\n'
def matrix = [:]
def headers = ['|Plugin Name']

// Loop over all online Client Masters
Jenkins.instance.getAllItems(ConnectedMaster.class).eachWithIndex{ it, index ->
  headers.add(it.name)
  if (it.channel) {
    def stream = new ByteArrayOutputStream();
    def listener = new StreamBuildListener(stream);
    // Execute remote Groovy script in the Client Master
    // Result of the execution must be a String
    it.channel.call(new MasterGroovyClusterOpStep.Script("""
        result = ''
        for (plugin in Jenkins.instance.pluginManager.plugins) {
            result = result + /"|\${plugin.getShortName()}"/ + ',' + /"|\${plugin.version}"\n/
        }
       return result
    """, listener, "host-script.groovy", [:]))
    retour = retour << "Master ${it.name}:\n${stream.toString().minus('Result: ')}"

    stream.toString().eachLine { line, count ->
      if (line?.trim()) {
        matcher = ( line =~ /"(.*)"*","(.*)"/ )

        if (matcher[0] && matcher[0].size() == 3) {
            if (!matrix[matcher[0][1]]) {
              matrix[matcher[0][1]] = ['|not_installed']
            }
              matrix[matcher[0][1]][index] = matcher[0][2]
        }
      }
    }
  }
}

Boolean printFormatted(headers, matrix) {

  def separator = ''
  def length_col_header = 42
  def lenght_col_versions = 19
  Boolean ret_val = false

  // Print the headers
  headers.eachWithIndex{ it, index ->
    def header =  (index == 0) ? it.padRight(length_col_header) + '| ' : it.padRight(lenght_col_versions - 3) + '| '
    print header
    separator += (index == 0) ? '|'.padRight(length_col_header, '-') : '|'.padRight(lenght_col_versions -1, '-')
  }
  print "\n" + separator + "|\n"

  //Print the plugin versions
  matrix.each{ k, v ->
    print k.padRight(length_col_header)
  
    def model = v[0]

    v.eachWithIndex{ it, index ->  
      def version = it 

      if ( index == 0 ) {
        print version.padRight(lenght_col_versions -1)
      } else if ( model == version ) {
        print version.padRight(lenght_col_versions -1)
      } else if ( model != version ) {
        print version.replace('|', '|**').padRight(lenght_col_versions -1)
        ret_val = true
      }
    }
    print '|\n'
  }
  return ret_val
}

Boolean inconsistencies = printFormatted(headers, matrix)

print "\nTotal Number of Pluings: " + matrix.size() + "\n\n"

if ( inconsistencies ) {
  print 'Inconsistencies found that have to be fixed.\n'
  return 1
} else {
  print 'No inconsistencies found, continuing...\n\n'
}

// This JSON string should be sent as a string argument to a Jenkins pipeline job in M6
def generateJSON(matrix) {
  def plugins = [:]
  
  matrix.each{ k, v ->
    plugins[k.replace('|','')] = v[0].replace('|','')
  }
  return JsonOutput.toJson(plugins.sort())
}

def json = generateJSON(matrix)
print 'JSON: \n'
print json + '\n\n'


// Execute Jenkins job in M6 and pass the JSON as parameter
def json_file = new File('/tmp','plugins.json') << json
'/Jenkins_Home/pluginsWikiGenerator.sh'.execute().text 


return 0
