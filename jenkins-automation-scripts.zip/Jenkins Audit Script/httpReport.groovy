import jenkins.model.Jenkins; 
import hudson.model.*; 
import com.cloudbees.hudson.*;
import com.cloudbees.hudson.plugins.folder.AbstractFolder;

//Folder Name
def folderName = "jenkinsmaster-3/ACT" //eg - root dir is 'Jenkins/'
// I want to disable jobs 
def PrintJobName = { println it.fullName + " >>> Build# " + it.getLastBuild();}

// Function to get current time
def Date getNowEST(){
    Calendar cal = Calendar.getInstance();
    cal.setTimeZone(TimeZone.getTimeZone("EST"));
    System.out.println(cal.toString());
    Date now = cal.getTime();
    return now;
}

currentTime = getNowEST()

println "-" * 80
println "Script started at : " +  currentTime + "\n"
println "-" * 80
println "List of jobs leveraging HTTP to connect to TFS"
doAllItemsInFolder(folderName, PrintJobName);


def doAllItemsInFolder(folderName, closure) {
  AbstractFolder folder = Jenkins.instance.getAllItems(AbstractFolder.class).find {folder -> folderName == folder.fullName };
  println folder
  folder.getAllJobs().findAll { job -> job.isBuildable()}.each {
            if (it.getLastBuild() != null ) {
                 // This would create a File object containing the console output for the lastbuild of a given job
                  File fic= it.getLastBuild().getLogFile()

              if (fic.text.contains("http://tfs")) {                       
                          closure(it)
               } 
            }  
  }
}


//println "Script completed : " +  currentTime + "\n"