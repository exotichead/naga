import com.cloudbees.hudson.plugins.folder.Folder
import com.cloudbees.hudson.plugins.folder.Folder
import nectar.plugins.rbac.groups.*
import java.util.*
import com.cloudbees.opscenter.server.model.*
import com.cloudbees.opscenter.server.clusterops.steps.*
import com.cloudbees.hudson.plugins.folder.*
import com.cloudbees.hudson.plugins.foldersplus.*
import jenkins.model.Jenkins;
import nectar.plugins.rbac.strategy.*;
import hudson.security.*;
import nectar.plugins.rbac.groups.*;
import nectar.plugins.rbac.roles.*;
import hudson.model.*;


//void processFolderByName(Item folder){
  //if(folder.getFullName().contains(folderName))
  //processFolder(folder)
//}

countFolder = 0
countFreeStyle = 0
countPipeline =0
countMaven=0

void processFolder(Item folder){
    println "Folder -  "+folder.getFullName()    
    folder.getItems().each{
        if(it instanceof org.jenkinsci.plugins.workflow.job.WorkflowJob){
        	countPipeline = countPipeline + 1
            println  "       Pipeline : " + it.getName()
        }
        else if(it instanceof hudson.tasks.Maven.DescriptorImpl){
        	countMaven = countMaven + 1
            println  "       Maven Project : " + it.getName()
        }
        else if(it instanceof hudson.model.FreeStyleProject){
        	countFreeStyle = countFreeStyle + 1
            println  "       Free Style Project : " + it.getName()
        }
        else if(it instanceof com.cloudbees.hudson.plugins.folder.AbstractFolder){
        	countFolder = countFolder +1
            processFolder(it)

        }
        else{
            processJob(it)
        }
    }
}

void processJob(Item job){
   println  "       Job : " + job.getName()
  // you can do operations like enable to disable
  // job.disable()
}

/////  Main Script   ////////
def allJobs= hudson.model.Hudson.getInstance().getItems()
for(int i=0; i<allJobs.size(); i++){
    def job = allJobs[i]
    if(job instanceof Folder){
        processFolder(job)
    }
}

println "countFolder :" + countFolder
println "countFreeStyle :" + countFreeStyle
println "countMaven :" + countMaven
println "countPipeline :" + countPipeline
