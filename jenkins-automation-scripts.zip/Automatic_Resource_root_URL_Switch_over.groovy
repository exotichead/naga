import jenkins.security.ResourceDomainConfiguration


// This script sets the Resource root URL
// https://javadoc.jenkins.io/jenkins/security/ResourceDomainConfiguration.html


def hostname = "hostname".execute().text
def resource_root_URL = "https://" + hostname.trim() + ".linux.us.ups.com:8443/"

rdc = ResourceDomainConfiguration.get()
rdc.setUrl(resource_root_URL)
println("The Resource Root URL has been set to: " + rdc.getUrl())
