import com.cloudbees.hudson.plugins.folder.AbstractFolder
import hudson.model.AbstractItem
import groovy.transform.Field
import hudson.model.*
import jenkins.model.Jenkins
import groovy.time.*

///////////////////  Edit this as per requirement //////////////////////////////////////////
def folderPath = "TTG/Flight-Crew/Flight/ACARS/"   // Folder path on jenkins master 
def numBuildsToKeep = 15 //   number of builds to keep 
def resetBuildNumber = false // If this is true, the build number will be set back to 1
@Field def numDaysToDelete = 15 // Set the number of days to remove the builds
@Field def cleanedJobsTotal = 0 // Global Variable
@Field def currentTime

////////////////////////////////////////////////////////////////////////////////////////////
currentTime = getNowEST()

println "\n Script started at : " +  currentTime + "\n"
println "\nTarget directory set as '${folderPath}'\n"
println "Number of builds to keep set as '${numBuildsToKeep}'\n"
println "Reset Build number set as '${resetBuildNumber}'\n"
println "Number of days to keep builds set as '${numDaysToDelete}'\n"


//Function call
removeBuilds(Jenkins.instance.getItemByFullName(folderPath), resetBuildNumber,numBuildsToKeep)

//Function for removing builds
def removeBuilds(job,resetBuildNumber, numBuildsToKeep){
	def count
    def a = job instanceof AbstractFolder
	//If the Instance is Folder
	if(job instanceof AbstractFolder){
		for (subJob in job.getItems()){
			//call removeBuild recursively
			removeBuilds(subJob, resetBuildNumber, numBuildsToKeep)
		}
	}
	// otherwise its a job instance
	else if (job instanceof Job) {
		count = 0 
		buildsDeleted = false
		exceptionFound = false
		println "Job: '" + job.name +"'\n"
		job.getBuilds().each{
			if(count < numBuildsToKeep ){ //leave first no. of builds in numBuildsToKeep variable
		        count++
		    }
		    else{
		    	def duration
		    	duration = TimeCategory.minus(currentTime, it.getTime()).days
		    	// Delete the build if it has passed the limit of numDaysToDelete
		    	if (duration >= numDaysToDelete  ){
                    println "	+ Build #" + it.number +"\n"
		    		try {
		    		 	it.delete()
		    		 	println "	+ Build #" + it.number +" Deleted\n"
		        		buildsDeleted = true

		    		 }
		    		 catch(java.io.IOException ex) {
		    		 	println "	+[WARNING] Unable to delete Build#" + it.number
		    		 	exceptionFound = true
		    		 }    		

		    	}
		    	else{
		    		println "	+ Build #" + it.number + " ran before " + duration + " days\n"
		    	}

		    } 
		}
		//check if the builds got deleted else tthere is less number of builds 
		if (buildsDeleted || !exceptionFound){ 
			println "	'"+ job.name + "' cleaned successfully.\n"			
		}
		else if (!buildsDeleted && !exceptionFound){
			println "	'" + job.name + "' has ${numBuildsToKeep} or less number of builds or all the builds are performed within last ${numDaysToDelete}.\n"			
		}
		else{
			//Pass
		}
		//if ask for build number to reset then 
		if (resetBuildNumber) {
     		job.nextBuildNumber = 1
      		job.save()
      		println "Next Build number set to 1 for " +job.name + "\n"
    	}
	}
	//throw exception
	else{ 
               println "HERE"
		throw new RuntimeException("Unsupported job type ${job.getClass().getName()}!\n")
	}
}


// Function to get current time
def Date getNowEST(){
    Calendar cal = Calendar.getInstance();
    cal.setTimeZone(TimeZone.getTimeZone("EST"));
    System.out.println(cal.toString());
    Date now = cal.getTime();
    return now;
}