import com.cloudbees.hudson.plugins.folder.AbstractFolder
import hudson.model.AbstractItem
import groovy.transform.Field
import hudson.model.*
import jenkins.model.Jenkins
import groovy.time.*

def folderPath = "MonilApp/"
logRotator(Jenkins.instance.getItemByFullName(folderPath))
def logRotator(job){
	 def a = job instanceof AbstractFolder
	 //If the Instance is Folder
	if(job instanceof AbstractFolder){
		for (subJob in job.getItems()){
			//call logRotator recursively
			logRotator(subJob)
		}
	}
	else if (job instanceof Job) {
		job.logRotator.perform(job)
	}
	else {
		throw new RuntimeException("Unsupported job type ${job.getClass().getName()}!\n")
	}
}
