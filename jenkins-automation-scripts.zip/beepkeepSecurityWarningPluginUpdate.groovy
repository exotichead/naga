import com.cloudbees.jenkins.plugins.assurance.CloudBeesAssurance;
import com.cloudbees.jenkins.cjp.installmanager.install.Config;
import com.cloudbees.jenkins.plugins.assurance.model.Beekeeper;
import com.cloudbees.jenkins.plugins.assurance.model.SecurityWarningData;
import com.cloudbees.jenkins.plugins.assurance.model.Status;
import hudson.Extension;
import hudson.model.AdministrativeMonitor;
import org.apache.commons.lang.StringUtils;
import org.kohsuke.accmod.Restricted;
import org.kohsuke.accmod.restrictions.NoExternalUse;
import org.kohsuke.stapler.HttpResponse;
import org.kohsuke.stapler.HttpResponses;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;
import org.kohsuke.stapler.interceptor.RequirePOST;
import jenkins.model.Jenkins;

Map<String,List> plugin_map  = new HashMap<>();
def EnvelopePluginsLst = new ArrayList()
def CompatiblePluginLst = new ArrayList()
upgradedPlugins = []
//Get the List of the plugins installed on the Master
def plugins = jenkins.model.Jenkins.instance.getPluginManager().getPlugins()

plugins.each {
     plugin_map.put(it.getLongName(),[it.getShortName(),it.getVersion()]);
     //println "${it.getLongName()}: ${it.getShortName()}: ${it.getVersion()}"
}
//plugin_map.each{ k, v -> println "${k}:${v[0]}" }
final Beekeeper beekeeper = CloudBeesAssurance.get().getBeekeeperOrNull();
SecurityWarningData data = beekeeper.getSecurityWarnings();

//def message = data.getSummary();
//println(message.toString())

def warnings = data.getWarnings();
//upgradedPlugins = []
warnings.each{w->

    if(w instanceof com.cloudbees.jenkins.plugins.assurance.model.SecurityWarningItem$Core){
        //println("Core");
    }else if(w instanceof com.cloudbees.jenkins.plugins.assurance.model.SecurityWarningItem$EnvelopePlugins){
        println("EnvelopePlugins Warnings ------------");
        //println("2    "+w.getName());
       // println("    "+w.getAction());
        w.getPlugins().each{p->
            println("        Plugin: "+p.getName());
            getPluginDetail = getPlugindetailLst(p.getName(), plugin_map)
            if(getPluginDetail){
                println("        Plugin ID: "+ getPluginDetail[0]);
                println("        Current Version: "+ getPluginDetail[1]);
                println("        + Starting Plugin Upgrade........")
                updatePlugin = updatePlugin(getPluginDetail[0])
                //println updatePlugin
            }
            println("        Action: "+ w.getAction());
            p.getAdvisories().each{ a->
                println("            Security ID: "+a.getAdvisoryId());
                println("            URL: "+a.getAction());
                println("            Description: "+a.getDescription());
            }
        }


    }else if(w instanceof com.cloudbees.jenkins.plugins.assurance.model.SecurityWarningItem$CompatiblePlugin){
        println("CompatiblePlugin ---------------");
        println("    Plugin: "+w.getName());
        //println("        Plugin ID: "+ plugin_map.get(w.getName())[0]);
       // println("        Current Version: "+ plugin_map.get(w.getName())[1]);
        getPluginDetail = getPlugindetailLst(w.getName(), plugin_map)
        if(getPluginDetail){
            println("        Plugin ID: "+ getPluginDetail[0]);
            println("        Current Version: "+ getPluginDetail[1]);
            println("        + Starting Plugin Upgrade........")
            updatePlugin = updatePlugin(getPluginDetail[0])
            println("        - Completed Plugin Upgrade........")

            //println updatePlugin
        }
        println("        Action: "+w.getAction());

        w.getAdvisories().each{ a->
            println("                Security ID: "+a.getAdvisoryId());
            println("                URL: "+a.getAction());
            println("                Description: "+a.getDescription());
        }

    }else if(w instanceof com.cloudbees.jenkins.plugins.assurance.model.SecurityWarningItem$Plugin){
        println("Plugins ------------------------");
        println("        Plugin: "+p.getName());
            p.getAdvisories().each{ a->
                println("            Security ID: "+a.getAdvisoryId());
                println("            URL: "+a.getAction());
                println("            Description: "+a.getDescription());
            }
    }else if(w instanceof com.cloudbees.jenkins.plugins.assurance.model.SecurityWarningItem$Advisory){
        //println("Advisory");  
    }
}

if(upgradedPlugins.size() > 0) {
    println("Some Plugins was updated.Restarting jenkins in safe mode...")
    jenkins.model.Jenkins.instance.safeRestart()
}



// ----------- Functions -----------
def getPlugindetailLst(pFullName,pluginMap){
    
    if(pluginMap.containsKey(pFullName)){
        return pluginMap.get(pFullName)
    }
    else{
        matchFound = false
        for(item in pluginMap){
            //println(item.key.toString() + " ::" + pFullName.toString() + " :: " + item.key.toLowerCase().contains(pFullName.toLowerCase()))
            if(item.key.toLowerCase().contains(pFullName.toLowerCase())){
                matchFound = true
                return pluginMap.get(item.key)
            }
        }
        if(!matchFound){
           println('${pFullName}  NOT FOUND !!!')
        }
    }
}

def updatePlugin(pluginId){
    println pluginId
    def instance = Jenkins.getInstance()
    def uc = instance.getUpdateCenter()
    def plugin = uc.getPlugin(pluginId)
    def pm = instance.getPluginManager()
    def plugin_pm = pm.getPlugin(pluginId)
    if(plugin){
        println "            - [Started] Resolving the Dependencies for ${pluginId}"
        plugin_pm.getDependencies().each { 
            //println("            Description: "+a.getDescription());
            println "                   o Dependency found: ${it.shortName}"
        }
        println "            - [Completed] Resolving the Dependencies for ${pluginId}"
        //Deploy the plugin
        
        plugin.deploy()
        upgradedPlugins.add(pluginId)
       // println "true"
        return true
    }
    return false
}
