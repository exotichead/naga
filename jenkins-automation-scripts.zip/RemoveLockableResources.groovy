// IMPORTANT NOTE : Set the Name of the Lockable resource that needs to be removed as value of LockableResourceName before you run the script
def LockableResourceName = "proxy.ups.com";
print "[INFO] : Set Lockable Resource Name -> ${LockableResourceName} to be removed from Jenkins Configuration.\n"
def count = 0;
def pluginManager = org.jenkins.plugins.lockableresources.LockableResourcesManager.get();
def lstOfLockableResources = pluginManager.getResources().findAll();
lstOfLockableResources.each(){
  if (it.name == LockableResourceName  && !it.locked){
    print "[FOUND] : Lockable Resource -> ${LockableResourceName}.\n";
     try {
        print "[INFO] : Trying to remove the Lockable Resource -> ${LockableResourceName}....\n";
        pluginManager.getResources().remove(it);
        print "[SUCCESS] : Successfully removed the Lockable Resource -> ${LockableResourceName}.\n";
        try{
          count = count + 1;
          print "[INFO] : Saving Changes in Jenkins Configuration...\n";
          pluginManager.save()
          print "[SUCCESS] : Successfully Saved Changes in Jenkins Configuration.\n";
        }catch(Exception ex) {
                print "[ERROR] : Failed to save changes in Jenkins Configuration.\n";
                print ex;
        }
      } catch(Exception ex) {
        print "[ERROR] : Failed to remove the Lockable Resource -> ${LockableResourceName}.\n";
        print ex;
      }
  }
}

if (count > 0){
  print "[INFO] : Successfully removed ${count} Lockable Resources.\n";
}
else{
  print "[INFO] : No Lockable Resources found with name ${LockableResourceName}.\n";
}