[System.Collections.ArrayList] $JenkinsMasterURLs = @("https://jenkins-oc.ams1907.com:8443/")
$UserName = "YPB6YXF"
$token ="11208ab9aabda4cf3d8be687386cbdf2bf"
$token="11faba29976c2c6438477baf5461d4baa9" #test
$Headers = @{ Authorization = "Basic {0}" -f [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $UserName,$token))) }

function Add-Row{
    Param(
        $worksheet,
        $row
    );
    $lastRow = $worksheet.UsedRange.Rows.Count + 1
    for ($i = 1;$i -le $row.Count;$i++){
        $worksheet.Cells.Item($lastRow,$i) = $row[$i-1]
    }
    return $worksheet
}


function getEmpID
{
    param($userADID)

    $bodyInfo = "UserID=" + $userADID + "&IDType=uuid"
    try {
        $res = Invoke-WebRequest -UseBasicParsing -Uri "https://ws4id.inside.ups.com/ws4id/SOAP-TEST/UserProfile2" -Method "POST" -Body $bodyInfo
        $xml = [xml]$res

        if ($xml.Envelope.Body.result.count -eq 0) {
            
            return "Invalid"
        }

        elseif ($xml.Envelope.Body.result.record.empid -eq "") {
           
            return "Not Found"
        }

        else {
            $empID = $xml.Envelope.Body.result.record.empid + "@ups.com"
            return $empID
        }

    }
    catch{
        $_
        Write-Host  "FAILED: Get Emp ID" -BackgroundColor Red
        Write-Host  "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Host  "StatusDescription:" $_.Exception.Response.StatusDescription   
        exit   
    }

}


function processFolder{
    param (
        $folderName,
        $folderURL
    )


    #get Group of the folder
    $groupsURL = $folderURL + "groups/api/json?tree=groups[name]"
    $groupsNameResult = (Invoke-WebRequest -Uri $groupsURL -Headers $Headers -Method Get).Content | ConvertFrom-Json
    $groupsNames = $groupsNameResult.groups.name
    Write-Host (" "*15)
    #Process each group
    foreach($groupName in $groupsNames){
        $groupMembersURL = $folderURL + "groups/" + $groupName + "/api/json"
        $groupMembersResult = (Invoke-WebRequest -Uri $groupMembersURL -Headers $Headers -Method Get).Content | ConvertFrom-Json
        #Jenkins old method used Members for membership so checking if any user are part of the old group struture and add them to user list
        foreach($member in $groupMembersResult.members){
            
            if(!$groupMembersResult.users -contains $member -AND !$groupMembersResult.groups -contains $member)
            {
               
                $groupMembersResult.users+= $member
            }
        }
        
        Write-Host (" "*15) + "Group : $groupName"
        
        #Process Each User
        foreach($user in $groupMembersResult.users){
            $empID = getEmpID -userADID $user

            
            $removeUserUrl = $folderURL + "groups/" + $groupName+"/removeUser?name="+$user
            $addUserUrl = $folderURL + "groups/" + $groupName+"/addUser?name="+$empID

            if($empID -eq "Invalid"){
                Write-Host (" "*20)"- $user is Invalid" -BackgroundColor Red
                ## To Do ########

                ##  removeUSerADID (API) ###

                Invoke-RestMethod -Method Post -Headers $Headers -Uri  $removeUserUrl
                $worksheet = Add-Row -worksheet $worksheet -row @($folderURL,$groupName,$user,"Invalid")

                ##   Make an entry in excel report with App Path ($folderURL), Group Name ($groupName) , ADID($user) and Status (Invalid ADID) ###

            }
            elseif($empID -eq "Not Found"){
                Write-Host (" "*20)"- EmployeeId Not found for $user" -BackgroundColor Red

                

                 ##  removeUSerADID (API) ###
                Invoke-RestMethod -Method Post -Headers $Headers -Uri  $removeUserUrl
                $worksheet = Add-Row -worksheet $worksheet -row @($folderURL,$groupName,$user,"Not Found")
                 ##   Make an entry in excel report with App Path ($folderURL), Group Name ($groupName) , ADID($user) and Status (Emp ID Not found) ###

            }
            else{
                Write-Host (" "*20)"- UserId: $user | EmpID: $empID"
                ## To Do ########
                
                ##  removeUSerADID (API) ###
                #Invoke-RestMethod -Method Post -Headers $Headers -Uri  $removeUserUrl
                ##  Add User EmpID (API) - Add $empID  ###
                Invoke-RestMethod -Method Post -Headers $Headers -Uri  $addUserUrl

                $worksheet = Add-Row -worksheet $worksheet -row @($folderURL,$groupName,$user,"Success")

                ##   Make an entry in excel report with App Path ($folderURL), Group Name ($groupName) , ADID($user) and Status (Completed) ###
            }
        }
        Write-Host (" "*15)
    }
    
}

function getFolderItems{
        param (
            $folderName,
            $folderURL,
            $folderfullName
        )
        if($folderfullName){
            $outString= "Folder: $folderfullName/$folderName"
        }else{
            $outString= "Folder: $folderName"
        }
        echo $outString
        #process the current folder for group
        processFolder -folderName $folderName -folderURL $folderURL -spaceLength $outString.Length

        #Get all items in the folder (recurssive fuction call until it doesn't find any folder)
        $folderResult = (Invoke-WebRequest -Uri  "$folderURL/api/json" -Headers $Headers -Method Get).Content | ConvertFrom-Json
        $folderfullName = $folderResult.fullName
        foreach ($item in $folderResult.jobs){
            if($item._Class -eq "com.cloudbees.hudson.plugins.folder.Folder"){
                 $childFolderName = $item.name
                 $childFolderURL = $item.url
                 
                 #echo "Child Folder : $childFolderName"
                 getFolderItems -folderName $childFolderName -folderURL $childFolderURL -folderfullName  $folderfullName
            }
        }
}


#main Function
foreach ($jenkinsURL in $JenkinsMasterURLs){
    #Get the Root Folders
    $jenkinsRootApiURL = $jenkinsURL + "/api/json"
    $jenkinsRootApiURL
    $result = (Invoke-WebRequest -Uri $jenkinsRootApiURL -Headers $Headers -Method Get).Content | ConvertFrom-Json


    $title = "MFA User Migration Status"
    $headrows = @("App Path","Group Name", "ADID", "Status")

    #$worksheet, $workbook, $excel = Initialize-Worksheet -worksheetTitle $title -headerRows $headrows
     $rows = $headrows
    $excel = New-Object -ComObject excel.application

    $excel.visible = $True
    $excel.DisplayAlerts = $False
    $workbook = $excel.Workbooks.Add()
    $workbook.Worksheets.Add()
    $worksheet = $workbook.Worksheets.Item(1)
    $worksheet.Name = "MFA User Migration Status"

    for ($i = 1;$i -le $rows.Count;$i++){
        $worksheet.Cells.Item(1,$i)= $rows[$i-1]
        $worksheet.Cells.Item(1,$i).Font.Bold=$True
        $worksheet.Cells.Item(1,$i).Font.Size = 14
        $worksheet.Columns[$i].columnWidth = 20
        }
    
    foreach ($item in $result.jobs){
        if($item._Class -eq "com.cloudbees.hudson.plugins.folder.Folder"){
            $baseFolderName = $item.name
            $baseFolderURL = $item.url
            echo "------------------------------------------------------------------------"
            echo "Base Folder : $baseFolderName  | $baseFolderURL "
            echo "------------------------------------------------------------------------"
            getFolderItems -folderName $baseFolderName -folderURL $baseFolderURL -folderfullName  $result.fullName
        }
    
    }

    $documentPath = [System.Environment]::GetFolderPath('MyDocuments')
    $currentTime = Get-Date -Format "dd-MMM-yy_HH-mm_ss"
    $fName = "MFA-User-Migration-Status-Report-$currentTime.xlsx"
    $path=$documentPath+"\$fName"
    $workbook.SaveAs($path)
    $workbook.Close
    $excel.Quit()

     #Finalize-Worksheet -workbook $workbook -excel $excel
     


}