﻿#Use TLSv1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12




# To recieve user input
function User-Input{

    $project_url= Read-Host("Enter the project url")
    $devops_user = Read-Host("Enter the username (Azure DevOps service hooks)")
    $devops_token = Read-Host("Enter the Token (Azure DevOps service hooks)")
    $jenkins_username = Read-Host("Enter you Jenkins username (EmployeeID@ups.com)")
    $jenkins_password = Read-Host("Enter your Jenkins token (new)")
    return $project_url,$devops_user,$devops_token,$jenkins_username,$jenkins_password

}




# To format username and password to header
function Make-Header{
    param(
        $username,
        $token
    )

    $pair = "${user}:${token}"
    $bytes = [System.Text.Encoding]::ASCII.GetBytes($pair)
    $base64 = [System.Convert]::ToBase64String($bytes)
    $basicAuthValue = "Basic $base64"
    $headers = @{ Authorization = $basicAuthValue }

    return $headers
    }




#EXECUTION STARTS HERE!


$jobsLimit = $args[0]

if ((-not $jobsLimit) -or ($jobsLimit -lt 0)){
    $jobsLimit = 2
}
if ($jobsLimit -gt 10){
    $jobsLimit = 10
}


# Step 1: Get user input
$projectUrl,$username,$token,$jenkinsUsername, $jenkinsPassword = User-Input



# Step 2: Extract organization name and project name
$pattern =[regex] "tfs\/([\w]+\/[\w]+)"
$projectUrl -match $pattern | Out-Null
    if ($Matches.Count -gt 1){
        $result = $Matches[1].Split("/")
        $organization,$project = $result[0],$result[1]
    }
    else{
        Write-Host("`nError parsing project URL. Please Enter correct project URL!")
        Exit
    }
    



# Step 3: Create Authentication Header
$headers = Make-Header -username $username -token $token

$get_service_hooks_api_url = "https://tfs.ups.com/tfs/"+ $organization +"/_apis/hooks/subscriptions?api-version=6.0"
$get_project_details_api_url = "https://tfs.ups.com/tfs/"+ $organization +"/_apis/projects/"+$project+"?api-version=6.0"




#Step 4: get service hook list
$step4 = {
    param($endpoint, $headers)
    try{
        Invoke-RestMethod -Uri $endpoint -Method Get -ContentType 'application/json'  -Headers $headers
       } catch{
            Write-Host("Error getting service hooks list")
            Write-Host("Error Message: ",$_.Exception.Message)
        Exit
       }
          
    }



# Step 5: get project details
$step5 = {
    param($endpoint,$headers)
    try{
        Invoke-RestMethod -Uri $endpoint -Method Get -ContentType 'application/json' -Headers $headers
        } catch{
            Write-Host("Error getting project details")
            Write-Host("Error Message: ",$_.Exception.Message)
        }
    }



#Execute Step 4 and Step 5 simultaneously
Write-Host("`nGathering project details and service hook list...")
$job1 = Start-Job -ScriptBlock $step4 -ArgumentList $get_service_hooks_api_url, $headers
$job2 = Start-Job -ScriptBlock $step5 -ArgumentList $get_project_details_api_url, $headers
Wait-Job -Job $job1, $job2 | Out-Null

Write-Host("Received service hook list and project details")

$serviceHooksListResponse  = Receive-Job -Job $job1
$projectDetailsResponse = Receive-Job -Job $job2

# Step 6: Filter service hooks based on project Id and realtion to Jenkins
$serviceHooks = $serviceHooksListResponse.value
$projectId = $projectDetailsResponse.id
$filteredHooks = @()
$filteredHooks += $serviceHooks | 
                    Where-Object {$_.publisherInputs.projectId -eq $projectId}|
                    Where-Object {$_.consumerId -ilike "jenkins" -or  $_.consumerId -ilike "webHooks" }|
                    Where-Object {$_.actionDescription -match "\bjenkins\b"}|
                    Where-Object {$_.consumerInputs.username -eq $username -or  $_.consumerInputs.basicAuthUsername -eq $username}
                    
if ($filteredHooks.Count -eq 0){
    Write-Host("No matching Hooks found!")
    Exit
}
else{
    Write-Host ("Found",$filteredHooks.Count, "Service hooks with matching ADID/Service account")
    Write-Host("Updating hooks...")
}

#Step 7: Update Jenkins username and password for the filtered entries
$numberOfHooks = $filteredHooks.Count
$numberOfBatch = [math]::ceiling($numberOfHooks/$jobsLimit)
$currentIndex = -1
$jobs = @()
$batchJobs = @()

for($batch = 0; $batch -lt $numberOfBatch; $batch++){
    for ($n = 0; $n -lt $jobsLimit; $n++){
        
        $currentIndex = $batch*$jobsLimit + $n
     

       

        if ($currentIndex -ge $filteredHooks.Count){
            break
            }

         Write-Host("Updating hook",($currentIndex+1))
            

        $hook = $filteredHooks[$currentIndex]
        $id = $hook.id

        #MAKE CHANGE HERE
        
        if ($hook.consumerId -like "Jenkins"){
            $hook.consumerInputs.password = $jenkinsPassword
            $hook.consumerInputs.username = $jenkinsUsername
        } else{
            $hook.consumerInputs.basicAuthPassword = $jenkinsPassword
            $hook.consumerInputs.basicAuthUsername = $jenkinsUsername
        }
        

        $update_service_hooks_api_url = "https://tfs.ups.com/tfs/"+$organization+"/_apis/hooks/subscriptions/"+$id+"?api-version=6.0"
        
        $job = Start-Job -ScriptBlock {
            Param($endpoint, $headers, $payload)
             try{
                Invoke-RestMethod -Uri $endpoint -Method Put -Body $payload -ContentType "application/json" -Headers $headers
                } catch{
                    Write-Host("Failed to update hooks with id ",$id," and actionDescription ",$hook.actionDescription)
                    Write-Host("Error Message: ",$_.Exception.Message)
                }
            } -ArgumentList $update_service_hooks_api_url,$headers,($hook|ConvertTo-Json)

        $batchJobs+=$job
        $jobs += $job
    }
    Wait-Job -Job $batchJobs |Out-Null
}

Write-Host("Service hooks update completed!")



