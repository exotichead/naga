import com.cloudbees.opscenter.server.model.*
import com.cloudbees.opscenter.server.clusterops.steps.*

// This script is meant to be run in the OC Script Console.
def matrix = [:]

// Loop over all online Client Masters
Jenkins.instance.getAllItems(ConnectedMaster.class).eachWithIndex{ it, index ->
  if (it.channel) {
    def stream = new ByteArrayOutputStream();
    def listener = new StreamBuildListener(stream);
    // Execute remote Groovy script in the Client Master
    // Result of the execution must be a String
    it.channel.call(new MasterGroovyClusterOpStep.Script("""
        // Report_CustomAgents_MGCOpStep.groovy
        import com.cloudbees.jenkins.plugins.nodesplus.OwnerNodeProperty

        def result = [:]
        def name
        def jobs
        def status
        def executors
        def host

        for ( computer in Jenkins.instance.getComputers() ) {
            if ( ! (computer instanceof jenkins.model.Jenkins.MasterComputer) ) {
                name = computer.getName()
                jobs = computer.getTiedJobs()
                status = ( computer.getChannel() != null ) ? 'Online' : 'Offline'
                executors = computer.getNumExecutors()
                host = computer.getDescription().trim()

                if ( name ==~ /^WindowsBuildAgent-.*/ || name ==~ /^dynamic-agent-.*/ || name ==~ /^jenkins-slave-.*/ || name ==~ /^openshift-ci-agent.*/ ||
                     name ==~ /^jenkins-agent-.*/ || name ==~ /^jenkins-.*-dynamic-agent-.*/ || name ==~ /^k8s-ci-agent.*/ ) { 
                    // don't add non custom agents to the result
                } else {
                    // add custom agetn's: executors, host, jobs, status.
                    if ( status == 'Online' && executors != null && host != null ) {
                        result['"' + name + '"'] = ' [Executors: "' + executors.toString() + '"' +
                        ', Host: "' + host + '"' +
                        ', Jobs: "' + jobs + '"' +
                        ', Status: "Online"'
                    } else {
                        //result['"' + name + '"'] = ' [Status: "Offline"'
                        //println(' [Executors: "' + executors.toString() + '"')
                        result['"' + name + '"'] = ' [Executors: "' + executors.toString() + '"' +
                        ', Host: "' + host + '"' +
                        ', Jobs: "' + jobs + '"' +
                        ', Status: "Offline"'
                    }
                }
			      }
        }

        for (node in Jenkins.instance.nodes) {
            name = node.getNodeName()

            if ( name ==~ /^WindowsBuildAgent-.*/ || name ==~ /^dynamic-agent-.*/ || name ==~ /^jenkins-slave-.*/ || name ==~ /^openshift-ci-agent.*/ ||
                 name ==~ /^jenkins-agent-.*/ || name ==~ /^jenkins-.*-dynamic-agent-.*/ || name ==~ /^k8s-ci-agent.*/ ) { 
                // don't add non custom agents to the result
            } else {
                // add custom agetn's: owners
                if ( node != null && result.containsKey('"' + name + '"') ) {
                    if ( node.getNodeProperties().get(OwnerNodeProperty.class) != null) { 
                        if ( node.getNodeProperties().get(OwnerNodeProperty.class).getOwners() != null ){
                        result['"' + node.getNodeName() + '"'] += ', Owners: "' + node.getNodeProperties().get(OwnerNodeProperty.class).getOwners().replaceAll(/\n/, '') + '"]'
                        } else {
                        result['"' + node.getNodeName() + '"'] += ', Owners: "not set"]'
                        }
                    } else {
                    result['"' + node.getNodeName() + '"'] += ']'
                    }
                } else {
                    result['"' + node.getNodeName() + '"'] += ']'
                }
            }
        }

       return result.toString()
       

    """, listener, "host-script.groovy", [:]))

    matrix.put(it.name, stream.toString().replace('Result: ', ''))
  }
}

Integer total_agents = 0
Integer total_executors = 0
Integer total_online_agents = 0
Integer total_offline_agents = 0
Integer executors_per_master
Integer agents_online_per_master
Integer agents_offline_per_master


for (master in matrix) {
    println('--------------------------------------------------------------------------------------------------------------------------------')
    println(master.key)
  	println('--------------------------------------------------------------------------------------------------------------------------------')
    
    agents = Eval.me(master.value)
    
    executors_per_master = 0
    agents_online_per_master = 0
    agents_offline_per_master = 0


    for (agent in agents) {

        if ( agent.value['Executors'].toInteger() != 1 ) {
          println(agent.key + " is online and has more than 1 executor, executors: " + agent.value['Executors'])
        }
        
        agents_online_per_master += ( agent.value['Status'] == 'Online' ) ? 1 : 0
        agents_offline_per_master += ( agent.value['Status'] == 'Offline' ) ? 1 : 0
        executors_per_master += agent.value['Executors'].toInteger()
    }

  	println('')	
    println('Custom Agents: ' + agents.size())
    println('Online custom agents: ' + agents_online_per_master )
    println('Offline custom agents: ' + agents_offline_per_master )
    println('Total executors: ' + executors_per_master.toString())
    println('')
    println('')

    total_executors += executors_per_master
    total_online_agents += agents_online_per_master
    total_offline_agents += agents_offline_per_master
    
}

total_agents = total_online_agents + total_offline_agents

println('--------------------------------------------------------------------------------------------------------------------------------')
println('Summary')
println('--------------------------------------------------------------------------------------------------------------------------------')
println('Total custom agents: ' + total_agents)
println('Total online custom agents: ' + total_online_agents)
println('Total offline custom agents: ' + total_offline_agents)
println('Total executors: ' + total_executors)
