import com.cloudbees.opscenter.server.model.*
import com.cloudbees.opscenter.server.clusterops.steps.*

// This script is meant to be run in the OC Script Console.
def matrix = [:]

// Loop over all online Client Masters
Jenkins.instance.getAllItems(ConnectedMaster.class).eachWithIndex{ it, index ->
  if (it.channel) {
    def stream = new ByteArrayOutputStream();
    def listener = new StreamBuildListener(stream);
    // Execute remote Groovy script in the Client Master
    // Result of the execution must be a String
    it.channel.call(new MasterGroovyClusterOpStep.Script("""
        import com.cloudbees.jenkins.plugins.nodesplus.OwnerNodeProperty

        def result = [:]
        def name
        def jobs
        def status
        def executors
        def host

        for ( computer in Jenkins.instance.getComputers() ) {
            if ( ! (computer instanceof jenkins.model.Jenkins.MasterComputer) ) {
                name = computer.getName()
                jobs = computer.getTiedJobs()
                status = ( computer.getChannel() != null ) ? 'Online' : 'Offline'
                executors = computer.getNumExecutors()
                host = computer.getDescription().trim()

                if ( status == 'Online' && executors != null && host != null ) {
                    result['"' + name + '"'] = ' [Executors: "' + executors.toString() + '"' +
                    ', Host: "' + host + '"' +
                    ', Jobs: "' + jobs + '"' +
                    ', Status: "Online"'
                } else {
                    result['"' + name + '"'] = ' [Status: "Offline"'
                }
			      }
        }

        for (node in Jenkins.instance.nodes) {
            if ( node != null && result.containsKey('"' + node.getNodeName() + '"') ) {
                if ( node.getNodeProperties().get(OwnerNodeProperty.class) != null) { 
                    if ( node.getNodeProperties().get(OwnerNodeProperty.class).getOwners() != null ){
                      result['"' + node.getNodeName() + '"'] += ', Owners: "' + node.getNodeProperties().get(OwnerNodeProperty.class).getOwners().replaceAll(/\n/, '') + '"]'
                    } else {
                      result['"' + node.getNodeName() + '"'] += ', Owners: "not set"]'
                    }
                } else {
                  result['"' + node.getNodeName() + '"'] += ']'
                }
            } else {
                result['"' + node.getNodeName() + '"'] += ']'
            }
        }

        for (agent in result) {
          if (agent.value == ' [Status: "Offline"') {
            agent.value = ' [Status: "Offline"]'
          }
        }

       return result.toString()
    """, listener, "host-script.groovy", [:]))

    matrix.put(it.name, stream.toString().replace('Result: ', ''))
  }
}

Integer total_agents = 0
Integer total_executors = 0
Integer total_online_agents = 0
Integer total_offline_agents = 0
Integer executors_per_master
Integer agents_online_per_master
Integer agents_offline_per_master


for (master in matrix) {
    println('--------------------------------------------------------------------------------------------------------------------------------')
    println(master.key)
  	println('--------------------------------------------------------------------------------------------------------------------------------')
    //println(master.value)
    
    agents = Eval.me(master.value)
    
    executors_per_master = 0
    agents_online_per_master = 0
    agents_offline_per_master = 0


    for (agent in agents) {
        /*
        println(agent.key)
        println('Executors: ' + agent.value['Executors'])
        println('Host: ' + agent.value['Host'])
        println('Owners: ' + agent.value['Owners'])
        println('Jobs: ' + agent.value['Jobs'])
        println('Status: ' + agent.value['Status'])
        println('')
        */

        if ( agent.value['Status'] == 'Online' && agent.value['Executors'].toInteger() != 1 ) {
          println(agent.key + " is online and has more than 1 executor, executors: " + agent.value['Executors'])
        }
        
        agents_online_per_master += ( agent.value['Status'] == 'Online' ) ? 1 : 0
        agents_offline_per_master += ( agent.value['Status'] == 'Offline' ) ? 1 : 0

        if ( agent.value['Status'] == 'Online' ) {
          executors_per_master += agent.value['Executors'].toInteger()
        }
    }

  	println('')	
    println('Total agents: ' + agents.size())
    println('Total agents online in this master: ' + agents_online_per_master )
    println('Total agents offline in this master: ' + agents_offline_per_master )
    println('Total executors of online agents: ' + executors_per_master.toString())
    println('')
    println('')

    total_executors += executors_per_master
    total_online_agents += agents_online_per_master
    total_offline_agents += agents_offline_per_master
    
}

total_agents = total_online_agents + total_offline_agents

println('--------------------------------------------------------------------------------------------------------------------------------')
println('Summary')
println('--------------------------------------------------------------------------------------------------------------------------------')
println('Total agents: ' + total_agents)
println('Total online agents: ' + total_online_agents)
println('Total offline agents: ' + total_offline_agents)
println('Total executors of online agents: ' + total_executors)
