        // This code is meant to be used inide of the Report_CustomAgents_* scripts as a MasterGroovyClusterOpStep 
        // Which means that this code will run in all the masters at onced

        import com.cloudbees.jenkins.plugins.nodesplus.OwnerNodeProperty

        def result = [:]
        def name
        def jobs
        def status
        def executors
        def host

        for ( computer in Jenkins.instance.getComputers() ) {
            if ( ! (computer instanceof jenkins.model.Jenkins.MasterComputer) ) {
                name = computer.getName()
                jobs = computer.getTiedJobs()
                status = ( computer.getChannel() != null ) ? 'Online' : 'Offline'
                executors = computer.getNumExecutors()
                host = computer.getDescription().trim()

                if ( name ==~ /^WindowsBuildAgent-.*/ || name ==~ /^dynamic-agent-.*/ || name ==~ /^jenkins-slave-.*/ || name ==~ /^openshift-ci-agent.*/ ||
                     name ==~ /^jenkins-agent-.*/ || name ==~ /^jenkins-.*-dynamic-agent-.*/ || name ==~ /^k8s-ci-agent.*/ ) { 
                    // don't add non custom agents to the result
                } else {
                    // add custom agetn's: executors, host, jobs, status.
                    if ( status == 'Online' && executors != null && host != null ) {
                        result['"' + name + '"'] = ' [Executors: "' + executors.toString() + '"' +
                        ', Host: "' + host + '"' +
                        ', Jobs: "' + jobs + '"' +
                        ', Status: "Online"'
                    } else {
                        //result['"' + name + '"'] = ' [Status: "Offline"'
                        //println(' [Executors: "' + executors.toString() + '"')
                        result['"' + name + '"'] = ' [Executors: "' + executors.toString() + '"' +
                        ', Host: "' + host + '"' +
                        ', Jobs: "' + jobs + '"' +
                        ', Status: "Offline"'
                    }
                }
			}
        }

        for (node in Jenkins.instance.nodes) {
            name = node.getNodeName()

            if ( name ==~ /^WindowsBuildAgent-.*/ || name ==~ /^dynamic-agent-.*/ || name ==~ /^jenkins-slave-.*/ || name ==~ /^openshift-ci-agent.*/ ||
                 name ==~ /^jenkins-agent-.*/ || name ==~ /^jenkins-.*-dynamic-agent-.*/ || name ==~ /^k8s-ci-agent.*/ ) { 
                // don't add non custom agents to the result
            } else {
                // add custom agetn's: owners
                if ( node != null && result.containsKey('"' + name + '"') ) {
                    if ( node.getNodeProperties().get(OwnerNodeProperty.class) != null) { 
                        if ( node.getNodeProperties().get(OwnerNodeProperty.class).getOwners() != null ){
                        result['"' + node.getNodeName() + '"'] += ', Owners: "' + node.getNodeProperties().get(OwnerNodeProperty.class).getOwners().replaceAll(/\n/, '') + '"]'
                        } else {
                        result['"' + node.getNodeName() + '"'] += ', Owners: "not set"]'
                        }
                    } else {
                    result['"' + node.getNodeName() + '"'] += ']'
                    }
                } else {
                    result['"' + node.getNodeName() + '"'] += ']'
                }
            }
        }

       return result.toString()
       