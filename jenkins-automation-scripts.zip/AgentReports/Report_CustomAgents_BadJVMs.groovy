import com.cloudbees.opscenter.server.model.*
import com.cloudbees.opscenter.server.clusterops.steps.*

// This script is meant to be run in the OC Script Console.
def matrix = [:]

// Loop over all online Client Masters
Jenkins.instance.getAllItems(ConnectedMaster.class).eachWithIndex{ it, index ->
  if (it.channel) {
    def stream = new ByteArrayOutputStream();
    def listener = new StreamBuildListener(stream);
    // Execute remote Groovy script in the Client Master
    // Result of the execution must be a String
    it.channel.call(new MasterGroovyClusterOpStep.Script("""
        import com.cloudbees.jenkins.plugins.nodesplus.OwnerNodeProperty

        def result = [:]
        def name
        def jobs
        def status
        def executors
        def host

        for ( computer in Jenkins.instance.getComputers() ) {
            if ( ! (computer instanceof jenkins.model.Jenkins.MasterComputer) ) {
                name = computer.getName()
                status = ( computer.getChannel() != null ) ? 'Online' : 'Offline'
                host = computer.getDescription().trim()

                if ( name ==~ /^WindowsBuildAgent-.*/ || name ==~ /^dynamic-agent-.*/ || name ==~ /^jenkins-slave-.*/ || name ==~ /^openshift-ci-agent.*/ ||
                     name ==~ /^jenkins-agent-.*/ || name ==~ /^jenkins-.*-dynamic-agent-.*/ || name ==~ /^k8s-ci-agent.*/ ) { 
                    // don't add non custom agents to the result
                } else {
                    // add custom agetn's: executors, host, jobs, status.
                    if ( status == 'Online' ) {
                        result['"' + name + '"'] = ' [Host: "' + host + '"' +
                        //', Sun_Java_Command: "' + computer.getSystemProperties()['sun.java.command'] + '"' +
                        //', Java_Home: "' + computer.getSystemProperties()['java.home'] + '"' +
                        //', User_Home: "' + computer.getSystemProperties()['user.home'] + '"' +
                        ', Java_Runtime_Name: "' + computer.getSystemProperties()['java.runtime.name'] + '"' +
                        ', Java_Runtime_Version: "' + computer.getSystemProperties()['java.runtime.version'] + '"' +
                        //', Java_Vendor: "' + computer.getSystemProperties()['java.vendor'] + '"' +
                        ', Java_VM_Name: "' + computer.getSystemProperties()['java.vm.name'] + '"' +
                        ', Java_VM_Vendor: "' + computer.getSystemProperties()['java.vm.vendor'] + '"' +
                        //', User_Dir: "' + computer.getSystemProperties()['user.dir'] + '"' +
                        //', User_Name: "' + computer.getSystemProperties()['user.name'] + '"' +
                        ', Status: "Online"'
                    } else {
                        result['"' + name + '"'] = ' [Host: "' + host + '"' +
                        ', Status: "Offline"'
                    }
                }
			      }
        }

        for (node in Jenkins.instance.nodes) {
            name = node.getNodeName()

            if ( name ==~ /^WindowsBuildAgent-.*/ || name ==~ /^dynamic-agent-.*/ || name ==~ /^jenkins-slave-.*/ || name ==~ /^openshift-ci-agent.*/ ||
                 name ==~ /^jenkins-agent-.*/ || name ==~ /^jenkins-.*-dynamic-agent-.*/ || name ==~ /^k8s-ci-agent.*/ ) { 
                // don't add non custom agents to the result
            } else {
                // add custom agetn's: owners
                if ( node != null && result.containsKey('"' + name + '"') ) {
                    if ( node.getNodeProperties().get(OwnerNodeProperty.class) != null) { 
                        if ( node.getNodeProperties().get(OwnerNodeProperty.class).getOwners() != null ){
                        result['"' + node.getNodeName() + '"'] += ', Owners: "' + node.getNodeProperties().get(OwnerNodeProperty.class).getOwners().replaceAll(/\n/, '') + '"]'
                        } else {
                        result['"' + node.getNodeName() + '"'] += ', Owners: "not set"]'
                        }
                    } else {
                    result['"' + node.getNodeName() + '"'] += ']'
                    }
                } else {
                    result['"' + node.getNodeName() + '"'] += ']'
                }
            }
        }

       return result.toString()
       
    """, listener, "host-script.groovy", [:]))

    matrix.put(it.name, stream.toString().replace('Result: ', ''))
  }
}

Integer total_agents = 0
Integer supported_jvms = 0
Integer unsupported_jvms = 0
Integer offline_agents = 0

for (master in matrix) {
    println('--------------------------------------------------------------------------------------------------------------------------------')
    println(master.key)
  	println('--------------------------------------------------------------------------------------------------------------------------------')
    //println(master.value)
    
    agents = Eval.me(master.value)

    for (agent in agents) {   
        total_agents += 1   
        // Only data can be retrieved from online agents. 
        if ( agent.value['Status'] == 'Online' ) {
            // If agent has a supported JVM
            if ( agent.value['Java_VM_Name'] == 'OpenJDK 64-Bit Server VM' && agent.value['Java_Runtime_Version'] ==~ /^1.8.*/ ) {
                supported_jvms += 1
                println(agent.key + ': OK')
            // If agent has an un-supported JVM
            } else {
                unsupported_jvms += 1
                println(agent.key + ': Unsupported JVM')
                println('Host: ' + agent.value['Host'] + ' OK')
                println('Java_Runtime_Name: ' + agent.value['Java_Runtime_Name'])
                println('Java_Runtime_Version: ' + agent.value['Java_Runtime_Version'])
                println('Java_VM_Name: ' + agent.value['Java_VM_Name'])
                println('Java_VM_Vendor: ' + agent.value['Java_VM_Vendor'])
                println('Owners: ' + agent.value['Owners'])
            }
        // Agent is Offline
        } else {
            offline_agents += 1
            println(agent.key + ': Offline')
        }
        println('')
    }    
    println('')
}

println('--------------------------------------------------------------------------------------------------------------------------------')
println('Summary')
println('--------------------------------------------------------------------------------------------------------------------------------')
println('')
println('Total Custom Agents: ' + total_agents.toString())
println('Supported JVMs: ' + supported_jvms.toString())
println('Unsupported JVMs: ' + unsupported_jvms.toString())
println('Offline Agents: ' + offline_agents.toString())
