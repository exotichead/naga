#!/bin/bash
#Jenkins Pre-Patch Status - Read json file of server list, log and send status report of each given server (active/standby)
#
#Author: Joshua DeSimpelare - IBM 2019
#Contact: vdesimpelare@ups.com
#
#Required files:
# -emailSendList.txt: List of email addresses to receive the status report. New line for each address.
# -JenkinsArchitecture.json: json file containing a list of jenkins servers in the environment sorted by datacenter and service.
#
#Instructions:
# -Run before jenkins patching has occurred in this environment.
# -Example: sh ./jenkinsPrePatchStatus.sh

set -o errexit

INFILEPATH="JenkinsArchitecture.json"
TOLISTFILE="emailSendList.txt"
LOGFILE="jenkinsPrePatchStatusLog.txt"
MESSAGEBODY=""

# sent email 
# $1 = recipient list $2 = subject $3 = string of html table rows
mailReport () {
sendmail "$1" <<EOF
subject:$2
from:noreply@ups.com
Content-Type: text/html
MIME-Version: 1.0
<html>
<body>
<table style="width:90%">
$3
</table>
</body>
</html>
EOF
	
}

# html formatting for datacenter headers in the email report
# $1 = datacenter $2 = environment $3 = caption (optional)
# output(string) = HTML table header row 
tableEntry () {
	local OUT="<tr><th></th></tr>
	<tr><th></th></tr>
	<tr><th colspan=\"3\" style=\"text-align:left;\">Data Center: $1 $2</th></tr>
	<tr><td>$3</td></tr>
	<tr><th style=\"text-align:left;\">Address</th><th style=\"text-align:left;\">Status</th><th style=\"text-align:left;\">Service</th><th style=\"text-align:left;\">Role</th></tr>"
	printf "${OUT}"
}

# Takes address, queries health check for address and outputs string describing return code
# $1 = address
# output(string) = status (active/standby/stopped/unreachable)
checkStatus () {
	local CODE="$(curl -o /dev/null --silent --head --write-out '%{http_code}\n' https://${1}:8443/ha/health-check)"
	if [[ $CODE == "200" ]]; then
		printf "active"
	elif [[ $CODE == "503" ]]; then
		printf "standby"
	elif [[ $CODE == "000" ]]; then
		if ping -c 1 $1 &> /dev/null ; then
			printf "stopped"
		else
			printf "unreachable"
		fi
	else
		printf "$CODE unknown"
	fi
}

# Process json file, output server status text file and generate report email body.
# $1 = server list json
readJson () {
	local INFILE=$1
	local ADDRESS=""
	local SERVICE=""
	local STATUS=""
	local DATACENTER=""
	local ENVIRONMENT=""
	local ACTION=""
	local ROLE=""
		
	#clear text file
	#printf "" > $OUTFILEPATH

	MESSAGEBODY="${MESSAGEBODY}<tr><td>Hostname: $(hostname)</td></tr><tr><td></td></tr>"
	
	if [[ -f $INFILE ]]; then
	while read p; do 
		# identify service
		if [[ $p == *"OC"* ]]; then
			SERVICE="jenkins-oc"
			ROLE="OC"
		fi
		if [[ $p == *"Master"* ]]; then
			SERVICE="jenkins"
			ROLE="$p"
			ROLE=${ROLE##*Master-}
			ROLE=${ROLE%\":*}
			ROLE="M$ROLE"
		fi
		if [[ $p == *"Active"* || $p == *"Standby"* ]]; then
			ADDRESS="$(printf $p | awk -F'"' '{print $4}')"
			# identify environment
			if [[ $ADDRESS == *"tsvr"* ]]; then
				ENVIRONMENT="Testnet"
			elif [[ $ADDRESS == *"psvr"* ]]; then
				ENVIRONMENT="Production"
			else
				ENVIRONMENT="unknown_environment"
			fi
			# identify datacenter and append datacenter header to report
			if [[ $ADDRESS == *"njrar"* ]]; then
				if [[ $DATACENTER != "Mahwah" ]]; then
					DATACENTER="Mahwah"
					MESSAGEBODY="$MESSAGEBODY$(tableEntry ${DATACENTER} ${ENVIRONMENT})"
				fi
				ACTION="start"
			elif [[ $ADDRESS == *"gaalp"* ]]; then
				if [[ $DATACENTER != "Windward" ]]; then
					DATACENTER="Windward"
					MESSAGEBODY="$MESSAGEBODY$(tableEntry ${DATACENTER} ${ENVIRONMENT})"
				fi
				ACTION="stop"
			else
				if [[ $DATACENTER != "Unknown" ]]; then
					DATACENTER="Unknown"
					MESSAGEBODY="$MESSAGEBODY$(tableEntry ${DATACENTER} ${ENVIRONMENT})"
				fi
				ACTION="none"
			fi
			# identify status
			STATUS="$(checkStatus $ADDRESS)"
			# set status color for report
			if [[ $STATUS == "active" ]]; then
				local COLORSTATUS="<font color="green">${STATUS}</font>"
			elif [[ $STATUS == "standby" ]]; then
				local COLORSTATUS="<font color="gold">${STATUS}</font>"
			elif [[ $STATUS == "stopped" ]]; then
				local COLORSTATUS="<font color="blue">${STATUS}</font>"
			else
				local COLORSTATUS="<font color="red">${STATUS}</font>"
			fi
			
			# append server info to report 
			MESSAGEBODY="$MESSAGEBODY"$"<tr><td>$ADDRESS</td><td>$COLORSTATUS</td><td>$SERVICE</td><td>$ROLE</td></tr>"
		fi
	done < $INFILE
	else
		printf "ERROR: Address action list: $INFILEPATH not found.\n"
		return 1
	fi
}

# direct output to file log file and output all commands
exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3
exec 1>$LOGFILE 2>&1
set -x
PS4='+\d \t '

#run if required files are are present.
if [[ -f $TOLISTFILE ]]; then
	TOLIST=$(<$TOLISTFILE)
	readJson "$INFILEPATH"
	mailReport "$TOLIST" "Jenkins Server Status Report" "$MESSAGEBODY"
else
	printf "ERROR: Email send list: $TOLISTFILE not found.\n"
	exit 1
fi
