#!/bin/bash
#Jenkins Patch Validator - start/stop remote jenkins services depending on datacenter then send email report including date of last jenkins patch.
#
#Author: Joshua DeSimpelare - IBM 2018
#Contact: vdesimpelare@ups.com
#
#Required files:
# -emailSendList.txt: List of email addresses to receive the status report. New line for each address.
# -JenkinsArchitecture.json: json file containing a list of jenkins servers in the environment sorted by datacenter and service.
# -sshHandler.py: Python script used to provide additional ssh functionality.
#Other files:
# -jenkinsPassword.txt: Should contain only the cleartext password of the jenkins user on the remote server. If not provided the script will prompt for the password.
#
#Instructions:
# -Run after jenkinsPrePatchStatus.sh and after jenkins patching has occurred in this environment.
# -Example: sh ./jenkinsPatchValidatior.sh
# -Note: If no password file has been provided then you will be promted the remote jenkins user password.

set -o errexit

INFILEPATH="JenkinsArchitecture.json"
LOGFILE="jenkinsPatchValidatorLog.txt"
TOLISTFILE="emailSendList.txt"
PASSFILE="jenkinsPassword.txt"
MESSAGEBODY=""

#get jenkins password from file or user.
if [ ! -f $PASSFILE ]; then
	JENKINSPASS=""
	read -sp "Password file not found: \"$PASSFILE\" Please enter jenkins password: " JENKINSPASS
	echo
else
	JENKINSPASS=$(<"$PASSFILE")
fi

#send email
# $1 = recipient list $2 = subject $3 = string of html table rows
mailReport () {
sendmail "$1" <<EOF
subject:$2
from:noreply@ups.com
Content-Type: text/html
MIME-Version: 1.0
<html>
<body>
<table style="width:90%">
$3
</table>
</body>
</html>
EOF
	
}

# html formatting for datacenter headers in the email report
# $1 = datacenter $2 = environment $3 = caption (optional)
# output(string) = HTML table header row
tableEntry () {
	local OUT="<tr><th></th></tr>
	<tr><th></th></tr>
	<tr><th colspan=\"3\" style=\"text-align:left;\">Data Center: $1 $2</th></tr>
	<tr><td>$3</td></tr>
	<tr><th style=\"text-align:left;\">Address</th><th style=\"text-align:left;\">Status</th><th style=\"text-align:left;\">Attempts</th><th style=\"text-align:left;\">Service</th><th style=\"text-align:left;\">Role</th><th style=\"text-align:left;\">Patch Date</th></tr>"
	printf "${OUT}"
}

# Takes address, queries health check for address and outputs string describing return code
# $1 = address
# output(string) = status (active/standby/stopped/unreachable)
checkStatus () {
	local CODE="$(curl -o /dev/null --silent --head --write-out '%{http_code}\n' https://${1}:8443/ha/health-check)"
	if [[ $CODE == "200" ]]; then
		printf "active"
	elif [[ $CODE == "503" ]]; then
		printf "standby"
	elif [[ $CODE == "000" ]]; then
		if ping -c 1 $1 &> /dev/null ; then
			printf "stopped"
		else
			printf "unreachable"
		fi
	else
		printf "$CODE unknown"
	fi
}

#Check if service is in desired state (started/stopped) 
#If not, attempt to start/stop service then return status and patch time.
#$1 = service name ("jenkins" or "jenkins-oc") $2 = action (start/stop/none)
# output(string) = outputstartSTATUS, ATTEMPTS, PATCHTIMEoutputend
validatePatch () {
	local SERVICE=$1
	local ACTION=$2
	local STATUS="unknown"
	local ATTEMPTS=0
	local MAXATTEMPTS=2
	local LOOP="true"
	
	while [[ $LOOP == "true" ]]; do
		if [[ $(/usr/sbin/service $SERVICE status) == *"(running)"* ]]; then
			STATUS="started" 
		elif [[ $(/usr/sbin/service $SERVICE status) == *"(dead)"* ]]; then
			STATUS="stopped" 
		else
			STATUS="unknown"
		fi
		
		# Is the service in the desired state
		if [[($STATUS == "started" && $ACTION == "start") || ($STATUS == "stopped" && $ACTION == "stop") || ($ACTION == "none") || ($STATUS == "unknown")]] ; then
			#echo "No action needed."
			LOOP="false"
		else
			if [[ $ATTEMPTS < $MAXATTEMPTS ]]; then
				ATTEMPTS=$((ATTEMPTS+1))
				sudo -n /usr/sbin/service $SERVICE $ACTION
			else
				STATUS="failed"
				LOOP="false"
			fi
		fi
	done
	
	# print status, attempts, date & time of last patch
	# The strings "outputstart" and "outputend" are added to aid in filtering out additional output from an ssh connection.
	printf "outputstart$STATUS $ATTEMPTS $(ls -ld /var/log/lct/monthly_patch | cut -d ' ' -f '6-8')outputend"
}

# Iterate through server list file, validate each server and generate email report body.
# $1 = server list file
processFile () {
	local INFILE=$1
	local ADDRESS=""
	local SERVICE=""
	local STATUS=""
	local ACTION=""
	local ATTEMPTS=""
	local PATCHTIME=""
	local DATACENTER=""
	local ENVIRONMENT=""
	local ROLE=""
	
	if [[ -f $INFILE ]]; then
		MESSAGEBODY="${MESSAGEBODY}<tr><td>Hostname: $(hostname)</td></tr><tr><td></td></tr>"
		while read p; do 
			# identify service
			if [[ $p == *"OC"* ]]; then
				SERVICE="jenkins-oc"
				ROLE="OC"
			fi
			if [[ $p == *"Master"* ]]; then
				SERVICE="jenkins"
				ROLE="$p"
				ROLE=${ROLE##*Master-}
				ROLE=${ROLE%\":*}
				ROLE="M$ROLE"
			fi
			if [[ $p == *"Active"* || $p == *"Standby"* ]]; then
				ADDRESS="$(printf $p | awk -F'"' '{print $4}')"
				# identify environment
				if [[ $ADDRESS == *"tsvr"* ]]; then
					ENVIRONMENT="Testnet"
				elif [[ $ADDRESS == *"psvr"* ]]; then
					ENVIRONMENT="Production"
				else
					ENVIRONMENT="unknown_environment"
				fi
				# identify datacenter and append datacenter header to report
				if [[ $ADDRESS == *"njrar"* ]]; then
					if [[ $DATACENTER != "Mahwah" ]]; then
						DATACENTER="Mahwah"
						MESSAGEBODY="$MESSAGEBODY$(tableEntry ${DATACENTER} ${ENVIRONMENT})"
					fi
					ACTION="start"
				elif [[ $ADDRESS == *"gaalp"* ]]; then
					if [[ $DATACENTER != "Windward" ]]; then
						DATACENTER="Windward"
						MESSAGEBODY="$MESSAGEBODY$(tableEntry ${DATACENTER} ${ENVIRONMENT})"
					fi
					ACTION="stop"
				else
					if [[ $DATACENTER != "Unknown" ]]; then
						DATACENTER="Unknown"
						MESSAGEBODY="$MESSAGEBODY$(tableEntry ${DATACENTER} ${ENVIRONMENT})"
					fi
					ACTION="none"
				fi
				
				#Execute function on remote server
				local OUT="$(python ./sshHandler.py jenkins@$ADDRESS "$(typeset -f validatePatch errorMail helpMessage); validatePatch $SERVICE $ACTION" $JENKINSPASS)"
				
				if [[ $OUT == *"ssh:"* ]]; then
					STATUS="unreachable"
					ATTEMPTS=""
					PATCHTIME=""
				elif [[ $OUT == *"Permission denied"* ]]; then
					STATUS="Permission denied"
					ATTEMPTS=""
					PATCHTIME=""
				elif [[ $OUT == *"outputstart"* ]]; then
					OUT=${OUT##*outputstart}
					OUT=${OUT%outputend*}
					#STATUS="$(echo $OUT | awk -F' ' '{print $1}')"
					STATUS="$(checkStatus $ADDRESS)"
					ATTEMPTS="$(echo $OUT | awk -F' ' '{print $2}')"
					PATCHTIME="$(echo $OUT | awk -F' ' '{print $3" "$4" "$5}')"
				else
					STATUS="Unknown Error"
					ATTEMPTS=""
					PATCHTIME=""
				fi
				#ADDRESS="$(echo $ADDRESS | awk -F'.' '{print $1}')"
				
				# set status color for report
				if [[ $STATUS == "active" ]]; then
					local COLORSTATUS="<font color="green">${STATUS}</font>"
				elif [[ $STATUS == "standby" ]]; then
					local COLORSTATUS="<font color="gold">${STATUS}</font>"
				elif [[ $STATUS == "stopped" ]]; then
					local COLORSTATUS="<font color="blue">${STATUS}</font>"
				else
					local COLORSTATUS="<font color="red">${STATUS}</font>"
				fi
				# append server info to report 
				MESSAGEBODY="$MESSAGEBODY"$"<tr><td>$ADDRESS</td><td>$COLORSTATUS</td><td>$ATTEMPTS</td><td>$SERVICE</td><td>$ROLE</td><td>$PATCHTIME</td></tr>"
			fi
		done < $INFILE
	else
		printf "ERROR: Address action list: $INFILEPATH not found.\n"
		return 1
	fi
}

# direct output to log file and output all commands
exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3
exec 1>$LOGFILE 2>&1
set -v
PS4='+\d \t '

#run if required files are are present.
if [[ -f $TOLISTFILE ]]; then
	TOLIST=$(<$TOLISTFILE)
	processFile "$INFILEPATH"
	mailReport "$TOLIST" "Jenkins Server Post-patch Report" "$MESSAGEBODY"
else
	printf "ERROR: Email send list: $TOLISTFILE not found.\n"
	exit 1
fi
