import jenkins.model.*
import hudson.remoting.Launcher
import hudson.slaves.SlaveComputer

def expectedVersion = Launcher.VERSION
for (computer in Jenkins.instance.getComputers()) {
  if (!(computer instanceof SlaveComputer)){
  	
    continue
  }
  if (!computer.getChannel()){
  	println "\n[OFFLINE] :${computer.name} is offline\n"
  	continue
  }	
  def version = computer.getSlaveVersion()
  if (!expectedVersion.equals(version)) {
    println "\n[Version-MissMatch] :${computer.name} - expected ${expectedVersion} but got ${version} which is different\n"
  }
  else{
    println "[Version-Matched] :${computer.name} - expected ${expectedVersion} and got ${version} which is same"
  }
}