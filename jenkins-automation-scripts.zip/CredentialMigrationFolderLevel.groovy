//This script should be runned on the /script URL of the target master where you want your new credentials

import com.cloudbees.hudson.plugins.folder.AbstractFolder
import com.cloudbees.hudson.plugins.folder.properties.FolderCredentialsProvider
import com.cloudbees.plugins.credentials.domains.DomainCredentials
import com.thoughtworks.xstream.converters.Converter
import com.thoughtworks.xstream.converters.MarshallingContext
import com.thoughtworks.xstream.converters.UnmarshallingContext
import com.thoughtworks.xstream.io.HierarchicalStreamReader
import com.thoughtworks.xstream.io.HierarchicalStreamWriter
import com.trilead.ssh2.crypto.Base64
import hudson.util.Secret
import hudson.util.XStream2
import jenkins.model.Jenkins
import com.cloudbees.plugins.credentials.domains.DomainCredentials
import com.trilead.ssh2.crypto.Base64
import hudson.util.XStream2
import jenkins.model.Jenkins
import com.cloudbees.plugins.credentials.Credentials

// Paste the encoded message from the script on the source Jenkins
// including double quotes " "
def encoded=[]
// If you encounter the error "String too long. The given string is X Unicode code units long, but only a maximum of 65535 is allowed." when running this script,
// save the encoded data to a file, such as /home/jenkins/credentials.txt in the active server you wanted to have the new credentials, omitting the starting [" and ending "], and un-comment the following line:
//encoded = [new File("/home/jenkins/credentials.txt").text]


if (!encoded) {
    return
}

HashMap<String, List<DomainCredentials>> credentialsList;

// The message is decoded and unmarshaled
for (slice in encoded) {
    def decoded = new String(Base64.decode(slice.chars))
    domainsFromFolders = new XStream2().fromXML(decoded) as HashMap<String, List<DomainCredentials>>  ;  
}

def instance = Jenkins.get()
def folderExtension = instance.getExtensionList(FolderCredentialsProvider.class)
if (!folderExtension.empty) {
  def folders = instance.getAllItems(AbstractFolder.class)
  def folderProvider = folderExtension.first()
  def store
  def domainName

    //targetFolder is where you want to move your credentials
    //e.g. targetFolder = instance.getItemByFullName("jenkinsmaster-7/OPT/AAA/SonarQube-Scans")
    targetFolder = instance.getItemByFullName("LOCATION_IS_GOING_TO")

    //sourceStore = folderProvider.getStore(sourceFolder)
    targetStore = folderProvider.getStore(targetFolder)

    println "Procesing Store for " + targetStore.getContext().getUrl()
    println targetStore.getContext().getUrl()  
    
  //folderDomains is where you export your credentials from
  //e.g. folderDomains = domainsFromFolders.get("job/Operations/job/AAA/job/SonarQube-Scans/")
    folderDomains = domainsFromFolders.get("LOCATION_WHERE_IS_COMING_FROM")
    if (folderDomains!=null) {
      for (domain in folderDomains) {
        domainName = domain.getDomain().isGlobal() ? "Global":domain.getDomain().getName()
        println "   Updating domain " + domainName
        for (credential in domain.credentials) {
            println "     Updating credential: " + credential.id;
            if (! targetStore.updateCredentials(domain.getDomain(), credential, credential) ){
                if (! targetStore.addCredentials(domain.getDomain(), credential) ){
                    targetStore "ERROR: Unable to add credential ${credential.id}"
                }
            }
        }
      }
    }
}