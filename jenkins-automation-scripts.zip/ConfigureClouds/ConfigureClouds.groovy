// TestNet - https://jenkins-oc.ams1907.com:8443/job/MasterMaintenanceScripts/job/ConfigureClouds/configure
// Prod - https://jenkins-oc.ups.com:8443/job/MasterMaintenanceScripts/job/ConfigureClouds/configure
import org.csanchez.jenkins.plugins.kubernetes.*
import org.csanchez.jenkins.plugins.kubernetes.volumes.workspace.EmptyDirWorkspaceVolume
import org.csanchez.jenkins.plugins.kubernetes.volumes.HostPathVolume
import com.google.common.collect.Lists
import org.csanchez.jenkins.plugins.kubernetes.model.KeyValueEnvVar
import groovy.json.JsonSlurper


ConfigObject config 

// Get config json from TFS
def config_url = new URL('https://tfs.ups.com/tfs/UpsProd/d6923c06-eeb3-4bf4-a6d4-8e43a8a0ec84/_apis/git/repositories/' +
                  'c3ab341c-5532-427b-8757-9b7a9e21775a/Items?path=%2FConfigureClouds%2Fconfig.json' +
                  '&versionDescriptor%5BversionOptions%5D=0' +
                  '&versionDescriptor%5BversionType%5D=0' +
                  '&versionDescriptor%5Bversion%5D=master' +
                  '&download=true' +
                  '&resolveLfs=true' +
                  '&%24format=octetStream' +
                  '&api-version=5.0-preview.1')
def auth = 'TFSAMTSKSvc:vvevnoyw76has7vilkmbwg3t2uiwbyxjdvyquyxo63kuu7wrthba'
def connection = config_url.openConnection()
connection.setRequestProperty("Authorization", "Basic " + auth.bytes.encodeBase64().toString())
connection.requestMethod = 'GET'

if (connection.responseCode == 200) {
    def response = connection.content.text
    connection.disconnect()
    def jsonSlurper = new JsonSlurper()
    config = jsonSlurper.parseText(response)
} else {
  prinltn ("failed to retrieve config.json")
  System.exit(1)
} 

// Validate config.json 
def pattern_containerImager = /^.+(:\d)*\/.+\/.+:.+$/  // E.g. xxxx-yyyy.zzz:5000/xxxx/yyyy-yyyy:zz.zz
config.cloud.each { cloudConfig ->
    cloudConfig.podTemplates.each { podTemplateConfig ->
        assert (podTemplateConfig.containerImager ==~ pattern_containerImager)
    }
}

// Prepare
def j = Jenkins.getInstanceOrNull()
def url = j.getRootUrl()
def masterNumber = ((url.split('-')[1]).tokenize('.')[0]).getAt(1)

// Remove all Kubernetes Clouds, avoid deleting "Operations Center Agent Provisioning Service" Cloud
clouds = Jenkins.instance.clouds
clouds.each { cloud ->
    if ( cloud instanceof org.csanchez.jenkins.plugins.kubernetes.KubernetesCloud ) {
      println "Removing: " + cloud.getClass().toString() + ", Name: " + cloud.name
      clouds.remove(cloud)
  }
}

// Add cloud configs
config.cloud.each { cloudConfig ->
    
    kc = new KubernetesCloud(cloudConfig.name)
    Jenkins.instance.clouds.add(kc)

    kc.setServerUrl(cloudConfig.serverUrl)
    kc.setSkipTlsVerify(cloudConfig.skipTlsVerify)
    kc.setNamespace(cloudConfig.namespace)
    kc.setJenkinsUrl(url)
    kc.setCredentialsId(cloudConfig.credentialsId)
    
    if (cloudConfig.websocket){
        
	    kc.setWebSocket(cloudConfig.websocket) 
	}    
    kc.setMaxRequestsPerHostStr(cloudConfig.maxRequestsPerHostStr)
    kc.setWaitForPodSec(cloudConfig.waitForPodSec)

    println("setting templates for: " + cloudConfig.name)
    kc.templates.clear()
 
    // Add PodTemplates 
    cloudConfig.podTemplates.each { podTemplateConfig ->
 
        def podTemplate = new PodTemplate()
        // Default for every container
        def container_name = 'jnlp'
        def always_pull_image = true
        def tty_enabled = false
        def command = ""
        def working_dir = '/home/jenkins/UPS'
        def args = '${computer.jnlpmac} ${computer.name}'
        def node_usage_mode = "EXCLUSIVE"
        def slave_connect_timeout = 100
        def idle_minutes = 1

        //set container
        def containerTemplate = new ContainerTemplate(container_name, podTemplateConfig.containerImager)
        containerTemplate.setWorkingDir(working_dir)
        containerTemplate.setArgs(args)        
        containerTemplate.setResourceRequestCpu(podTemplateConfig.resourceRequestCpu)
        containerTemplate.setResourceRequestMemory(podTemplateConfig.resourceRequestMemory)
        containerTemplate.setResourceLimitCpu(podTemplateConfig.resourceLimitCpu)
        containerTemplate.setResourceLimitMemory(podTemplateConfig.resourceLimitMemory)
        containerTemplate.setAlwaysPullImage(always_pull_image)
        containerTemplate.setTtyEnabled(tty_enabled)
        containerTemplate.setCommand(command)
        

        //set pod template        
        //podTemplate.setName(podTemplateConfig.name.replaceAll("#",masterNumber))
        podTemplate.setName(podTemplateConfig.label + '-m' + masterNumber)
        podTemplate.setLabel(podTemplateConfig.label)
        podTemplate.setContainers(Lists.newArrayList(containerTemplate))
        podTemplate.setNodeUsageMode(node_usage_mode)
        podTemplate.setIdleMinutes(idle_minutes)
        podTemplate.setSlaveConnectTimeout(slave_connect_timeout)
        if (podTemplateConfig.instanceCap){
            podTemplate.setInstanceCap(podTemplateConfig.instanceCap)
        }

	if (podTemplateConfig.nodeSelector){
	    podTemplate.setNodeSelector(podTemplateConfig.nodeSelector) 
	}
        
        //def envVars
         if (podTemplateConfig.keyValueEnvVar) { 
            envVars = new ArrayList<KeyValueEnvVar>() 
            podTemplateConfig.keyValueEnvVar.each { keyValueEnvVar ->
                envVars << new KeyValueEnvVar(keyValueEnvVar.key, keyValueEnvVar.value)
            }
            podTemplate.setEnvVars(envVars)
        }

        println "adding ${podTemplateConfig.name}"
        kc.templates << podTemplate
    }
}

// save changes to jenkins
j.save()
