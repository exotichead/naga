Jenkins.instance.clouds.each { cloud -> 
  println('----------------------------------------------------')
  println(cloud)
  println('----------------------------------------------------')
  println()
}

println('')