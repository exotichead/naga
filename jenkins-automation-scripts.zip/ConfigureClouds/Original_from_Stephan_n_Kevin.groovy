import hudson.model.*
import jenkins.model.*
import org.csanchez.jenkins.plugins.kubernetes.*
import org.csanchez.jenkins.plugins.kubernetes.volumes.workspace.EmptyDirWorkspaceVolume
import org.csanchez.jenkins.plugins.kubernetes.volumes.HostPathVolume
import com.google.common.collect.Lists
import org.csanchez.jenkins.plugins.kubernetes.model.KeyValueEnvVar


def j = Jenkins.getInstanceOrNull()
def url = j.getRootUrl()
def masterNumber = ((url.split('-')[1]).tokenize('.')[0]).getAt(1)

j.clouds.clear()
ConfigObject conf = new ConfigSlurper().parse(new File('var/tmp/jenkins_config/kubernetes.txt').text)

// ------------------------------------------------
// New Kubernetes Cloud Instance
// ------------------------------------------------

conf.kubernetes.cloud.each { cloudConfig ->
    kc = new KubernetesCloud(cloudConfig.name)
    Jenkins.instance.clouds.add(kc)    

    kc.setServerUrl(cloudConfig.serverUrl)
    kc.setSkipTlsVerify(cloudConfig.skipTlsVerify)
    kc.setNamespace(cloudConfig.namespace)
    kc.setJenkinsUrl(url)
    kc.setCredentialsId(cloudConfig.credentialsId)
    kc.setMaxRequestsPerHostStr(cloudConfig.maxRequestsPerHostStr)
    kc.setWaitForPodSec(cloudConfig.waitForPodSec)

    println "set templates"
    kc.templates.clear()
 
    // ------------------------------------------------
    // New Kubernetes Pod Instance
    // ------------------------------------------------
    cloudConfig.podTemplates.each { podTemplateConfig ->
 
        def podTemplate = new PodTemplate()

        //set container
        def containerTemplate = new ContainerTemplate(podTemplateConfig.containerName, podTemplateConfig.containerImager)
        containerTemplate.setWorkingDir(podTemplateConfig.workingDir)
        containerTemplate.setArgs(podTemplateConfig.args)        
        containerTemplate.setResourceRequestCpu(podTemplateConfig.resourceRequestCpu)
        containerTemplate.setResourceRequestMemory(podTemplateConfig.resourceRequestMemory)
        containerTemplate.setResourceLimitCpu(podTemplateConfig.resourceLimitCpu)
        containerTemplate.setResourceLimitMemory(podTemplateConfig.resourceLimitMemory)
            //Default for every container
        containerTemplate.setAlwaysPullImage(true)
        containerTemplate.setTtyEnabled(false)
        containerTemplate.setCommand("")
        

        //set pod template        
        podTemplate.setName(podTemplateConfig.name.replaceAll("#",masterNumber))
        podTemplate.setLabel(podTemplateConfig.label)
        podTemplate.setContainers(Lists.newArrayList(containerTemplate))
        podTemplate.setNodeUsageMode(podTemplateConfig.nodeUsageMode)
        podTemplate.setIdleMinutes(podTemplateConfig.idleMinutes)
        podTemplate.setSlaveConnectTimeout(podTemplateConfig.slaveConnectTimeout)
        if (podTemplateConfig.instanceCap){
            podTemplate.setInstanceCap(podTemplateConfig.instanceCap)
        }
        
        //def envVars
         if (podTemplateConfig.keyValueEnvVar) { 
            envVars = new ArrayList<KeyValueEnvVar>() 
            podTemplateConfig.keyValueEnvVar.each { keyValueEnvVar ->
                envVars << new KeyValueEnvVar(keyValueEnvVar.key, keyValueEnvVar.value)
            }
            podTemplate.setEnvVars(envVars)
        }

        println "adding ${podTemplateConfig.name}"
        kc.templates << podTemplate
    }
}
//replace cloud in jenkins
//j.clouds.replace(kc)

// save changes to jenkins
j.save()
