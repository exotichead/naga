﻿clear-host
#######################################################################
#Variable Decleration #################################################
#######################################################################

#Authentication
$JENKINS_USER="nnm2lyt"
$JENKINS_API_TOKEN="1122079b04b1f0e6d6dbc90c3a243cd932"

#Master Selection
$JENKINS_URL="https://jenkins-oc.ups.com:8443"


#computerName
$ComputerName = $env:computername
$HostFileComputerName = "WKSP00091C17"
$AgentFiles = "//WKSP00091C17/Users/nnm2lyt/Desktop/SharedAgentFiles/"


#Node Properties
$NODE_NAME="TestAgent"
$NODE_DESCRIPTION=${ComputerName}
$NODE_NUMEXECUTERS="3"
$NODE_ROOTDIRECTORY="C:\Program Files\jenkins\$NODE_NAME"
$NODE_LABEL="TestAgent"

#Env Variables
$NODE_ENV1 = "Git"
$NODE_ENV1_PATH = "C:\Program Files\Git\bin\git.exe" 

$javaVersion = ""
#######################################################################
#Setup Jenkins Node ###################################################
#######################################################################

#Add authentication into Headers of request
$bytes = [System.Text.Encoding]::ASCII.GetBytes("${JENKINS_USER}:${JENKINS_API_TOKEN}")
$base64 = [System.Convert]::ToBase64String($bytes)
$basicAuthValue = "Basic $base64"
$headers = @{ Authorization = $basicAuthValue;  }


$hash=@{name= "${NODE_NAME}";
 
  node= @{
    description= "${NODE_DESCRIPTION}";
    numExecutors= "${NODE_NUMEXECUTERS}"; 
    remoteFS= "${NODE_ROOTDIRECTORY}";
    labelString= "${NODE_LABEL}"; 
    mode= "EXCLUSIVE"; 
    ""= @(
        "com.cloudbees.opscenter.server.jnlp.slave.JocJnlpSlaveLauncher";
        'hudson.slaves.RetentionStrategy$Always')
    "launcher"= @{
        "stapler-class"= "com.cloudbees.opscenter.server.jnlp.slave.JocJnlpSlaveLauncher"; 
        "agentStartupOptions"= ""; 
        "tunnel"= ""; 
        "vmargs"= ""};
    "retentionStrategy"= @{
        "stapler-class"= "hudson.slaves.RetentionStrategy$Always";
        '$class'= 'hudson.slaves.RetentionStrategy$Always'
        }};
    "properties"= @{
        "stapler-class-bag"= "true"
        "com-cloudbees-opscenter-server-properties-SharedSlaveNodePropertyCustomizer"= @{
            "customizers"= @{
                "value"= @{
                    "env"= @{
                        "key"= "${NODE_ENV1}";
                        "value"= "${$NODE_ENV1_PATH}"}};
            "stapler-class"= "com.cloudbees.opscenter.server.properties.EnvironmentVariablesNodePropertyCustomizer";
        "$class"= "com.cloudbees.opscenter.server.properties.EnvironmentVariablesNodePropertyCustomizer"}}
    };
    "core:apply"= "";
    "enable"= $true; 
     }


#get Json objext
$JSON_OBJECT = $hash | convertto-json  -Depth 5
#write-host $JSON_OBJECT

#######################################################################
#Pre Check ############################################################
#######################################################################

$files = get-childitem C:\ -file -Filter "java.exe" -erroraction 'silentlycontinue' -r 

#Find Java Location
foreach ($file in $files)
{
    if(($file.FullName -like '*\java\*') -and ($file.FullName -like '*\bin\*') )
    {
        write-host $file.FullName
        $javaVersion = $file.FullName
    }
}
#If no java found stop
if ([string]::IsNullOrEmpty($javaVersion)){
    write-host "No Java installed on machine"
    break
}
#######################################################################
#Create Jenkins Node ##################################################
#######################################################################

#Create Jenkins Node
try{
$test = Invoke-WebRequest -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Uri "${JENKINS_URL}/view/all/createItem?name=${NODE_NAME}&mode=com.cloudbees.opscenter.server.model.SharedSlave"
}
catch
{
    if ($_ -like "*Invalid password/token*")
    {
        write-host "Password Inccorrect. Retype Password and Restart"
        break
    }
    if ($_ -like "*already exists*")
    {
        write-host "Agent Already Exists. Pick another name and restart"
        break
    }  
}

$test = Invoke-WebRequest -Headers $headers -ContentType "application/x-www-form-urlencoded" -Body "json=${JSON_OBJECT}" -Method POST -Uri "${JENKINS_URL}/job/${NODE_NAME}/configSubmit"

break
#######################################################################
#Get Jenkins Node Secret ##############################################
#######################################################################

#Get Jenkins Node Secret
$secretSauce = Invoke-WebRequest -Headers $headers -Method GET -Uri "${JENKINS_URL}/job/${NODE_NAME}/"

$sauce = $secretSauce.Content
$sauce = $sauce.Replace('<span id="jnlp-url">',"")
$sauce = $sauce.Replace('</span>',"")

$startIndex = $sauce.IndexOf("-jnlpUrl")
$middleIndex = $sauce.IndexOf("-secret")
$SecretLength = 72
$indexLength = $middleIndex - $startIndex + $SecretLength

$UrlSecret = $sauce.Substring($startIndex,$indexLength)

$secret = $UrlSecret.Substring($UrlSecret.IndexOf("-secret"))
$jnlpURL = $UrlSecret.Replace($secret, "")


########################################################################
##Setup Agent Files ####################################################
########################################################################

if(!(test-path $NODE_ROOTDIRECTORY))
{
    New-Item -ItemType Directory -Force -Path $NODE_ROOTDIRECTORY
}

#copy Agent Files from host Server
Copy-Item -Path $AgentFiles/* -Destination $NODE_ROOTDIRECTORY
#${JENKINS_URL}/jnlpJars/slave.jar

Invoke-WebRequest (-join($JENKINS_URL,"jnlpJars/agent.jar")) -OutFile "$NODE_ROOTDIRECTORY\agent.jar" -Headers $headers

#Get XML file
[xml]$XmlDocument = Get-Content -Path ("$NODE_ROOTDIRECTORY\jenkins-slave.xml")

#Set variables in XML file
$args = $XmlDocument.service.arguments
$args = $args.replace("-jnlpUrl",$jnlpURL)
$args = $args.replace("-secret",$secret)

$XmlDocument.service.arguments = $args
$XmlDocument.service.id = $NODE_NAME
$XmlDocument.service.name = $NODE_NAME
$XmlDocument.service.executable = $javaVersion

$XmlDocument.Save("$NODE_ROOTDIRECTORY\jenkins-slave.xml")

#######################################################################
#Install and Start Service#############################################
#######################################################################

#install Service
$path = "$NODE_ROOTDIRECTORY\jenkins-slave.exe"
$install = "install"
& $path $install

#Start Service
Start-Service -name $NODE_NAME
        
$winService = Get-Service -name $NODE_NAME
        
if ($winService.Status -eq "Stopped"){
    Write-Host ("Service is BROKEN, Please open a PLSHelpRequest")
    break
}

#######################################################################
#Validate and Exit ####################################################
#######################################################################

#bring shared build agent online
Invoke-WebRequest -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Uri "${JENKINS_URL}/job/${NODE_NAME}/enable"

write-host "validating Agent has conected to Master"

$response = Invoke-WebRequest -Headers $headers -Method GET -Uri "${JENKINS_URL}/computer/${NODE_NAME}/"

if ($response -like "*Connect agent to Jenkins one of these ways*")
{
    write-host "Service is running, But Agent did not connect to Master"
    break
}

write-host "Agent Successfully Conected" -ForegroundColor Green