﻿######################################################################################################################################
# NNM2LYT - Kevin Butryn                                                  ############################################################
# United Parcel Service of America (c)                                    ############################################################
# Update Jenkins Build Agent                                              ############################################################
######################################################################################################################################
clear-host

$targetFile = "jenkins-slave.xml"
$locationNewJar = "C:\Users\nnm2lyt\Desktop\slave.jar"

$jenkinsAgentDirectory = ""
$jenkinsAgentId = ""
$jenkinsAgentName = ""
$jenkinsAgentArguments = ""
$usesSlave = $false
$usesAgent = $false



get-psdrive -p "FileSystem" `
| % {

    write-host -f Green "Searching " $_.Root
    $files = get-childitem $_.Root -file -Filter $targetFile -erroraction 'silentlycontinue' -r 
    

    foreach ($file in $files)
    {
    
        $jenkinsAgentDirectory = $file.Directory
        write-host "Jenkins Directory = " $jenkinsAgentDirectory 

        if($jenkinsAgentDirectory -like 'D:\UPSData*')
        {
            write-host("Skipping UPSDATA folder")
            break
        }
        
        #Get contents of XML file and parse
        [xml]$XmlDocument = Get-Content -Path ("$jenkinsAgentDirectory\$targetFile ")
        Write-Host $XmlDocument.service
        
        $jenkinsAgentId = $XmlDocument.service.id
        $jenkinsAgentName = $XmlDocument.service.name
        $jenkinsAgentArguments = $XmlDocument.service.arguments
        
        #checks if agent uses slave.jar or agent.jar
        if($jenkinsAgentArguments -like '*slave.jar*'){
            $usesSlave = $true
        }
        elseif($jenkinsAgentArguments -like '*agent.jar*')
        {
            $usesAgent = $true
        }else
        {
            write-host ("ERROR JAR NOT FOUND IN CONFIG")
            break
        }
        
        
        #Stop Service on Build Agent
        Stop-Service -name $jenkinsAgentId
        $winService = Get-Service -name $jenkinsAgentId
        
        if ($winService.Status -eq "Running"){
            Write-Host ("Service is still running, Error Rerun.")
            break
        }
        
        #backup Jar file
        if($usesSlave){
            
            if (Test-Path ("$jenkinsAgentDirectory\slave_backup.jar")) 
            {
                Remove-Item ("$jenkinsAgentDirectory\slave_backup.jar")
            }
            Rename-Item -Path ("$jenkinsAgentDirectory\slave.jar") -NewName "slave_backup.jar"
        
        }elseif ($usesAgent){
            if (Test-Path ("$jenkinsAgentDirectory\agent_backup.jar")) 
            {
                Remove-Item ("$jenkinsAgentDirectory\agent_backup.jar")
            }
            Rename-Item -Path ("$jenkinsAgentDirectory\agent.jar") -NewName "agent_backup.jar"
        
        }
        
        #copy new JAR File from Host Server
        Copy-Item -Path $locationNewJar -Destination $jenkinsAgentDirectory
        
        
        #rename to slave.jar if needed
        #if($usesSlave){
        #    Rename-Item -Path ("$jenkinsAgentDirectory\agent.jar") -NewName "slave.jar"
        #}
        if($usesAgent){
            Rename-Item -Path ("$jenkinsAgentDirectory\slave.jar") -NewName "agent.jar"
        }
        
        #Start Service on Build Agent
        Start-Service -name $jenkinsAgentId
        
        $winService = Get-Service -name $jenkinsAgentId
        
        if ($winService.Status -eq "Stopped"){
            Write-Host ("Service is BROKEN, Please open a PLSHelpRequest")
            break
        }
        
        Write-Host("SUCCESS!!! Build Agent Upgraded")
        
        }
}
