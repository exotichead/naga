﻿clear-host
#######################################################################
#Variable Decleration #################################################
#######################################################################

#Authentication
$JENKINS_USER=""
$JENKINS_API_TOKEN="" #Token or Password

#Master Selection
#$JENKINS_URL="https://jenkins-m1.ups.com:8443/"
#$JENKINS_URL="https://jenkins-m2.ups.com:8443/"
#$JENKINS_URL="https://jenkins-m3.ups.com:8443/"
#$JENKINS_URL="https://jenkins-m4.ups.com:8443/"
#$JENKINS_URL="https://jenkins-m5.ups.com:8443/"
#$JENKINS_URL="https://jenkins-m6.ups.com:8443/"

#computerName
$ComputerName = $env:computername
$HostFileComputerName = "SVRP00082966"
$AgentFiles = "C:\AgentFiles\*"

#Node Properties
$NODE_NAME="TestAgent1"
$NODE_DESCRIPTION= ${ComputerName}
$NODE_NUMEXECUTERS="5"
$NODE_ROOTDIRECTORY="C:\Program Files\jenkins\$NODE_NAME"
$NODE_LABEL="TestAgent" 
$NODE_OWNERS="EXAMPLE@UPS.COM"
$NODE_FOLDER="https://jenkins-m6.ups.com:8443/job/jenkinsmaster-6/job/Europe-IT/job/CDMv/"

#variable Decleration
$javaVersion = ""
$JENKINS_URL = ($NODE_FOLDER -split ("job"))[0]
#######################################################################
#Setup Jenkins Node ###################################################
#######################################################################

#Add authentication into Headers of request
$bytes = [System.Text.Encoding]::ASCII.GetBytes("${JENKINS_USER}:${JENKINS_API_TOKEN}")
$base64 = [System.Convert]::ToBase64String($bytes)
$basicAuthValue = "Basic $base64"
$headers = @{ Authorization = $basicAuthValue;  }

#node json properties
$hash=@{
    name="${NODE_NAME}";
    nodeDescription="${NODE_DESCRIPTION}";
    numExecutors="${NODE_NUMEXECUTERS}";
    remoteFS="${NODE_ROOTDIRECTORY}";
    labelString="${NODE_LABEL}";
    mode="EXCLUSIVE";
    ""=@(
            "hudson.slaves.JNLPLauncher";
            'hudson.slaves.RetentionStrategy$Always'
        );
    launcher=@{ 
        "stapler-class"="hudson.slaves.JNLPLauncher";
        "\$class"="hudson.slaves.JNLPLauncher";
        "workDirSettings"=@{
            "disabled"="true";
            "workDirPath"="";
            "internalDir"="remoting";
            "failIfWorkDirIsMissing"="false"
        };
        "tunnel"="";
        "vmargs"=""
        };
        "retentionStrategy"=@{
            "stapler-class"= 'hudson.slaves.RetentionStrategy$Always';
           '$class'= 'hudson.slaves.RetentionStrategy$Always'
        };
        "nodeProperties"=@{
        "stapler-class-bag"= "true";
         "com-cloudbees-jenkins-plugins-nodesplus-OwnerNodeProperty"=@{
         "owners"="${NODE_OWNERS}";
         "onOnline"= "false";
         "onOffline"= "false";
         "onLaunchFailure"= "false";
         "onFirstLaunchFailure"= "true";
         "onTemporaryOfflineApplied"= "true";
         "onTemporaryOfflineRemoved"= "true"}}
    }

#get Json objext
$JSON_OBJECT = $hash | convertto-json  -Depth 5
#write-host $JSON_OBJECT

#######################################################################
#Pre Check ############################################################
#######################################################################
write-host "Starting Script"
$hostname = $JENKINS_URL.Replace("https://","").Replace(":8443/","")
[int]$port = [int]$hostname.Replace("jenkins-m","").Replace(".ups.com","") + 50000

#check connection to Master
$ip = [System.Net.Dns]::GetHostAddresses($hostname) | select-object IPAddressToString -expandproperty  IPAddressToString
$t = New-Object Net.Sockets.TcpClient
$t.Connect($ip,$port)

if($t.Connected)
{
    $t.Close()
    #write-host "FireWall rules in place"
}
else
{
    write-host "FIREWALL RULES NOT IN PLACE"
    break
}


#get all Java locations
write-host "Looking for java version on the server"
$files = get-childitem C:\ -file -Filter "java.exe" -erroraction 'silentlycontinue' -r 
write-host "---"

#Find Java Location
foreach ($file in $files)
{
    if(($file.FullName -like '*\java\*') -and ($file.FullName -like '*\bin\*') )
    {
        write-host $file.FullName
        $javaVersion = $file.FullName
    }
}

#If no java found stop
if ([string]::IsNullOrEmpty($javaVersion)){
    write-host "No Java installed on machine"
    break
}
write-host "---"

#######################################################################
#Create Jenkins Node ##################################################
#######################################################################
write-host "Creating Jenkins Custom Build Agent" 
$url = "$($JENKINS_URL)/crumbIssuer/api/xml"
try{
[xml]$crumbs = Invoke-WebRequest $url -Method GET -Headers $headers
}
catch
{
    if ($_ -like "*Invalid password/token*")
    {
        write-host "Password Inccorrect. Retype Password and Restart"
        break
    }
}
$headers.Add($crumbs.defaultCrumbIssuer.crumbRequestField, $crumbs.defaultCrumbIssuer.crumb)
$headers.Add("Accept", "application/xml")

try{
    $test = Invoke-WebRequest -Credential $cred -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}" -Uri "${JENKINS_URL}/computer/doCreateItem?name=${NODE_NAME}&type=hudson.slaves.DumbSlave" 
}
catch
{
    #$exceptionDetails = $_.Exception
    if ($_ -like "*already exists*")
    {
        write-host "Agent Already Exists. Pick another name and restart"
        break
    }  
}


#######################################################################
#Get Jenkins Node Secret ##############################################
#######################################################################
write-host "Getting Node Secret"
#Get Jenkins Node Secret
$secretSauce = Invoke-WebRequest -Headers $headers -Method GET -Uri "${JENKINS_URL}/computer/${NODE_NAME}/"

$startIndex = $secretSauce.content.IndexOf("-jnlpUrl")
$middleIndex = $secretSauce.content.IndexOf("-secret")
$SecretLength = 72
$indexLength = $middleIndex - $startIndex + $SecretLength

$UrlSecret = $secretSauce.Content.Substring($startIndex,$indexLength)

$secret = $UrlSecret.Substring($UrlSecret.IndexOf("-secret"))
$jnlpURL = $UrlSecret.Replace($secret, "")

#######################################################################
#Setup Agent Files ####################################################
#######################################################################

write-host "Setting up Agent Files"
if(!(test-path $NODE_ROOTDIRECTORY))
{
    New-Item -ItemType Directory -Force -Path $NODE_ROOTDIRECTORY
}

#copy Agent Files from host Server               
$Session = New-PSSession -ComputerName $HostFileComputerName -Credential $cred
Copy-Item $AgentFiles -Destination $NODE_ROOTDIRECTORY -FromSession $Session

#verify Files where copied
if(!(test-path "$NODE_ROOTDIRECTORY\jenkins-slave.xml"))
{
    write-host "ERROR Agent Files where not copied"
    break
}

Invoke-WebRequest (-join($JENKINS_URL,"jnlpJars/agent.jar")) -OutFile "$NODE_ROOTDIRECTORY\agent.jar" -Headers $headers

#Get XML file
[xml]$XmlDocument = Get-Content -Path ("$NODE_ROOTDIRECTORY\jenkins-slave.xml")

#Set variables in XML file
$args = $XmlDocument.service.arguments
$args = $args.replace("-jnlpUrl",$jnlpURL)
$args = $args.replace("-secret",$secret)

$XmlDocument.service.arguments = $args
$XmlDocument.service.id = $NODE_NAME
$XmlDocument.service.name = $NODE_NAME
$XmlDocument.service.executable = $javaVersion

$XmlDocument.Save("$NODE_ROOTDIRECTORY\jenkins-slave.xml")

#######################################################################
#Install and Start Service#############################################
#######################################################################

write-host "Installing and Starting Services"
#install Service
$path = "$NODE_ROOTDIRECTORY\jenkins-slave.exe"
$install = "install"
& $path $install

#Start Service
Start-Service -name $NODE_NAME
        
$winService = Get-Service -name $NODE_NAME
        
if ($winService.Status -eq "Stopped"){
    Write-Host ("Service is BROKEN, check error log")
    break
}

#######################################################################
#Validate and Exit ####################################################
#######################################################################

write-host "validating Agent has conected to Master"
Start-Sleep -s 15
$response = Invoke-WebRequest -Headers $headers -Method GET -Uri "${JENKINS_URL}/computer/${NODE_NAME}/"

if ($response.Content -like "*Connect agent to Jenkins one of these ways*")
{
    write-host "Service is running, But Agent did not connect to Master"
    break
}

write-host "Agent Successfully Conected" -ForegroundColor Green

#######################################################################
#Restrict Agent to Folder##############################################
#######################################################################

#Create Folder Token
$url = "$($NODE_FOLDER)controlled-slaves/requestSubmit"
$crumbToken = $crumbs.defaultCrumbIssuer.crumb

try
{
    $Response = Invoke-RestMethod $url -Headers $headers -Method POST  -ContentType "application/x-www-form-urlencoded" -Body "Jenkins-Crumb:${$crumbToken}"
}
catch
{
     $message = $_.ErrorDetails.Message
     $folderToken = $message.replace('%2F',"/").split("/")[-1].split("');")[0]  
}

#Create Agent Token
$url = "$($JENKINS_URL)computer/$($NODE_NAME)/security-tokens/createSubmit"
$Form = @{'Jenkins-Crumb'= "${crumbToken}"}
$JSON_OBJECT = $Form | convertto-json  -Depth 5

try 
{
    Invoke-RestMethod $url -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}"
}
catch 
{
    $message = $_.ErrorDetails.Message
    $agentToken = $message.replace('%2F',"/").split("/")[-1].split("');")[0]
    write-host $requestKey_agent
}

#Get Agent Value by using Folder Token
$url = "$($JENKINS_URL)computer/$($NODE_NAME)/security-tokens/tokensById/$($agentToken)/authorizeSubmit"
$Form = @{"salt"= "${folderToken}"; "$redact"= "salt"; "Jenkins-Crumb"= "${crumbToken}"}
$JSON_OBJECT = $Form | convertto-json  -Depth 5

try
{
    $response =  Invoke-RestMethod $url -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}"
}
catch
{
}
$splits =  $response -split 'value="'
$agentValue = $splits[2].Substring(0,32)
write-host $requestValue_Agent

#Restrict Agent to Folder by using Agent Value
$url = "$($NODE_FOLDER)controlled-slaves/grantsById/$($folderToken)/authorizeSubmit"
$Form = @{"salt"= "${folderToken}"; "hash"= "${agentValue}"; "$redact"= "hash"; "Jenkins-Crumb"= "${crumbToken}"}
$JSON_OBJECT = $Form | convertto-json  -Depth 5

try
{
    $response = Invoke-RestMethod $url -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}"
}
catch
{    
}

#Verify Agent is Restricted to Folder
$url = "$($JENKINS_URL)computer/testing123/security-tokens/"
try
{
    $response = Invoke-RestMethod $url -Headers $headers -Method GET 
    $shortFolder = $NODE_FOLDER.Replace($JENKINS_URL, "")    
}
catch
{    
    $_
}

if ($Response -like "*$shortFolder*"){
    write-host "AGENT IS RESTRICTED TO FOLDER"
}else
{
    write-host "AGENT IS NOT RESTRICTED TO FOLDER"
}

#######################################################################
#FINISHED #############################################################
#######################################################################