﻿
#Jenkins Job paramater Inputs
$jenkinsUsername = $ENV:jenkinsUser
$jenkinsPassword = $ENV:jenkinsPass
$serverUsername = $ENV:serverUser
$serverPassword = $ENV:serverPass
$server = $ENV:ServerName
$owner = $ENV:ServerOwner
$agentName = $ENV:AgentName
$folder = $ENV:JenkinsFolderURL
$workitemid = $ENV:workItemID

$jenkinsUsername = # Kevin's ADID 
$jenkinsPassword = # Kevin's Token

write-host " jenkins username: $jenkinsUsername"
write-host " jenkins password: $jenkinsPassword "
write-host " server username: $serverUsername"
write-host " server password: $serverPassword"
write-host " -----------------------------"
write-host " Jenkins Agent Creation Parameters"
write-host " Server to be configured into an agent: $server "  
write-host " Owner of the Agent: $owner " 
write-host " Agent name in Jenkins: $agentName " 
write-host " Jenkins folder to be bound to: $folder "
write-host " Azure work Item id: $workitemid " 
write-host " -----------------------------" 

$serverPassword = ConvertTo-SecureString "$($serverPassword)" -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ("$serverUsername", $serverPassword)

If (Test-Connection -ComputerName $server -Quiet)
{    
    $result = Invoke-Command -Credential $cred -ComputerName $server -ScriptBlock {
    
        
        param($jenkinsUsername,$jenkinsPassword,$owner,$agentName,$folder,$cred)

  
        #######################################################################
        #Variable Decleration #################################################
        #######################################################################

        #Authentication
        $JENKINS_USER=$jenkinsUsername
        $JENKINS_API_TOKEN=$jenkinsPassword 

        $JENKINS_URL= -join ("https://jenkins-m",$masterNumber,".ups.com:8443/")

        #computerName
        $ComputerName = $env:computername
        $HostFileComputerName = "SVRP00082966"
        $AgentFiles = "C:\AgentFiles\*"

        #Node Properties
        $NODE_NAME=$agentName
        $NODE_DESCRIPTION= ${ComputerName}
        $NODE_NUMEXECUTERS="1"
        $NODE_ROOTDIRECTORY="C:\Program Files\jenkins\$NODE_NAME"
        $NODE_LABEL= $NODE_NAME #Labels for build agent
        $NODE_OWNERS= $owner #emails for owner of node
        $NODE_FOLDER=$folder

        #Variable Decleration
        $javaVersion = "C:\openjdk-8u282-b08\bin\java.exe"
        $JENKINS_URL = ($NODE_FOLDER -split ("job"))[0]
        #######################################################################
        #Setup Jenkins Node ###################################################
        #######################################################################

        #Add authentication into Headers of request
        $bytes = [System.Text.Encoding]::ASCII.GetBytes("${JENKINS_USER}:${JENKINS_API_TOKEN}")
        $base64 = [System.Convert]::ToBase64String($bytes)
        $basicAuthValue = "Basic $base64"
        $headers = @{ Authorization = $basicAuthValue;  }

        #node json properties
        $hash=@{
            name="${NODE_NAME}";
            nodeDescription="${NODE_DESCRIPTION}";
            numExecutors="${NODE_NUMEXECUTERS}";
            remoteFS="${NODE_ROOTDIRECTORY}";
            labelString="${NODE_LABEL}";
            mode="EXCLUSIVE";
            ""=@(
                    "hudson.slaves.JNLPLauncher";
                    'hudson.slaves.RetentionStrategy$Always'
                );
            launcher=@{ 
                "stapler-class"="hudson.slaves.JNLPLauncher";
                "\$class"="hudson.slaves.JNLPLauncher";
                "workDirSettings"=@{
                    "disabled"="true";
                    "workDirPath"="";
                    "internalDir"="remoting";
                    "failIfWorkDirIsMissing"="false"
                };
                "tunnel"="";
                "vmargs"=""
                };
                "retentionStrategy"=@{
                    "stapler-class"= 'hudson.slaves.RetentionStrategy$Always';
                   '$class'= 'hudson.slaves.RetentionStrategy$Always'
                };
                "nodeProperties"=@{
                "stapler-class-bag"= "true";
                "com-cloudbees-jenkins-plugins-foldersplus-SecurityTokensNodeProperty"= @{
                    "acceptTasksWithoutOwningItem"= "false"}
                 "com-cloudbees-jenkins-plugins-nodesplus-OwnerNodeProperty"=@{
                 "owners"="${NODE_OWNERS}";
                 "onOnline"= "false";
                 "onOffline"= "false";
                 "onLaunchFailure"= "false";
                 "onFirstLaunchFailure"= "true";
                 "onTemporaryOfflineApplied"= "true";
                 "onTemporaryOfflineRemoved"= "true"}}
            }
     
        #get Json objext
        $JSON_OBJECT = $hash | convertto-json  -Depth 5
        #write-host $JSON_OBJECT
     
        #######################################################################
        #Pre Check ############################################################
        #######################################################################
        write-host "Starting Script"
        $hostname = $JENKINS_URL.Replace("https://","").Replace(":8443/","")
        [int]$port = [int]$hostname.Replace("jenkins-m","").Replace(".ups.com","") + 50000
        #$masterNumber = $masterNumber -as [int]
     
        #check connection to Master
        $ip = [System.Net.Dns]::GetHostAddresses($hostname) | select-object IPAddressToString -expandproperty  IPAddressToString
        $t = New-Object Net.Sockets.TcpClient
        $t.Connect($ip,$port)
     
        if($t.Connected)
        {
            $t.Close()
            #write-host "FireWall rules in place"
        }
        else
        {
            write-host "FIREWALL RULES NOT IN PLACE"
            return -1
            break
        }
     
     
        #get all Java locations
        #write-host "Looking for java version on the server"
        #$files = get-childitem C:\ -file -Filter "java.exe" -erroraction 'silentlycontinue' -r 
        #write-host "---"
     
        #Find Java Location
        #foreach ($file in $files)
        #{
        #    if($file.FullName -like '*\bin\*') 
        #    {
        #        write-host $file.FullName
        #        $javaVersion = $file.FullName
        #    }
        #}
     
        #If no java found stop
        #if ([string]::IsNullOrEmpty($javaVersion)){
        #    write-host "No Java installed on machine"
        #    return -1
        #    break
        #}
        #write-host "---"
     
        #######################################################################
        #Create Jenkins Node ##################################################
        #######################################################################
        write-host "Creating Jenkins Custom Build Agent" 
        #$url = "$($JENKINS_URL)/crumbIssuer/api/xml"
        #try{
        #[xml]$crumbs = Invoke-WebRequest $url -Method GET -Headers $headers
        #}
        #catch
        #{
        #    if ($_ -like "*Invalid password/token*")
        #     {
        #        write-host "Password Inccorrect. Retype Password and Restart"
        #        break
        #    }
        #}
        #$headers.Add($crumbs.defaultCrumbIssuer.crumbRequestField,$crumbs.defaultCrumbIssuer.crumb)
        #$headers.Add("Accept", "application/xml")
     
        try{
          $test = Invoke-WebRequest -UseBasicParsing -TimeoutSec 60 -Credential $cred -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}" -Uri "${JENKINS_URL}/computer/doCreateItem?name=${NODE_NAME}&type=hudson.slaves.DumbSlave" 
        }
        catch
        {
            #$exceptionDetails = $_.Exception
            if ($_ -like "*already exists*")
            {
                write-host "Agent Already Exists. Pick another name and restart"
                return -1
                break
            }  
        }
        write-host "agent should be created"
     
        #######################################################################
        #Get Jenkins Node Secret ##############################################
        #######################################################################
        write-host "Getting Node Secret"
        #Get Jenkins Node Secret
        $secretSauce = Invoke-WebRequest -UseBasicParsing -Headers $headers -Method GET -Uri "${JENKINS_URL}/computer/${NODE_NAME}/"
 

         if ($secretSauce -eq "")
         {
          write-host "couldnt get the agent secret"
          return -1
          }

        $startIndex = $secretSauce.content.IndexOf("-jnlpUrl")
        $middleIndex = $secretSauce.content.IndexOf("-secret")
        $SecretLength = 72
        $indexLength = $middleIndex - $startIndex + $SecretLength
     
        $UrlSecret = $secretSauce.Content.Substring($startIndex,$indexLength)
     
        $secret = $UrlSecret.Substring($UrlSecret.IndexOf("-secret"))
        $jnlpURL = $UrlSecret.Replace($secret, "")
     
        if ($secret -eq "")
        {
         write-host "secret is empty"
         return -1
         }
        write-host "$secret"
        write-host "Secret created"
        #######################################################################
        #Setup Agent Files ####################################################
        #######################################################################
     
        write-host "Setting up Agent Files"
        if(!(test-path $NODE_ROOTDIRECTORY))
        {
            New-Item -ItemType Directory -Force -Path $NODE_ROOTDIRECTORY
        }
     
        #copy Agent Files from host Server               
        $Session = New-PSSession -ComputerName $HostFileComputerName -Credential $cred
        Copy-Item $AgentFiles -Destination $NODE_ROOTDIRECTORY -FromSession $Session
     
     
        #verify Files where copied
        if(!(test-path "$NODE_ROOTDIRECTORY\jenkins-slave.xml"))
        {
            write-host "ERROR xml Files where not copied"
            return -1
            break
        }
     
        #Invoke-WebRequest (-join($JENKINS_URL,"jnlpJars/agent.jar")) -OutFile "$NODE_ROOTDIRECTORY\agent.jar" -Headers $headers
     
        if(!(test-path "$NODE_ROOTDIRECTORY\slave.jar"))
        {
            write-host "ERROR slave.jar Files where not copied"
            return -1
            break
        }
      
      	if(!(test-path "$NODE_ROOTDIRECTORY\openjdk8.zip"))
        {
            write-host "ERROR openjdk8.zip Files where not copied"
            return -1
            break
        }else
        {
            write-host "Unzip OpenJDK"
            Expand-Archive -Force "$NODE_ROOTDIRECTORY\openjdk8.zip" C:\
            Remove-Item "$NODE_ROOTDIRECTORY\openjdk8.zip"
        }
     
        #Get XML file
        [xml]$XmlDocument = Get-Content -Path ("$NODE_ROOTDIRECTORY\jenkins-slave.xml")
     
        #Set variables in XML file
        $args = $XmlDocument.service.arguments
        $args = $args.replace("-jnlpUrl",$jnlpURL)
        $args = $args.replace("-secret",$secret)
     
        $XmlDocument.service.arguments = $args
        $XmlDocument.service.id = $NODE_NAME
        $XmlDocument.service.name = $NODE_NAME
        $XmlDocument.service.executable = $javaVersion
     
        $XmlDocument.Save("$NODE_ROOTDIRECTORY\jenkins-slave.xml")
        
        write-host "files conigured"
        #######################################################################
        #Install and Start Service#############################################
        #######################################################################
     
        write-host "Installing and Starting Services"
        #install Service
        $path = "$NODE_ROOTDIRECTORY\jenkins-slave.exe"
        $install = "install"
        & $path $install
     
        #Start Service
        Start-Service -name $NODE_NAME
        
        $winService = Get-Service -name $NODE_NAME
        
        if ($winService.Status -eq "Stopped"){
            Write-Host ("Service is BROKEN, check error log")
            return -1
            break
        }
     
        #######################################################################
        #Validate and Exit ####################################################
        #######################################################################
     
        write-host "validating Agent has conected to Master"
        Start-Sleep -s 15
        $response = Invoke-WebRequest -UseBasicParsing -Headers $headers -Method GET -Uri "${JENKINS_URL}/computer/${NODE_NAME}/"
     
        if ($response.Content -like "*Connect agent to Jenkins one of these ways*")
        {
            write-host "Service is running, But Agent did not connect to Master"
            return -1
            break
        }
     
        write-host "Agent Successfully Conected" -ForegroundColor Green
     
        #######################################################################
        #Restrict Agent to Folder##############################################
        #######################################################################
           
        $url = "$($JENKINS_URL)/crumbIssuer/api/xml"
        try{
        [xml]$crumbs = Invoke-WebRequest $url -Method GET -Headers $headers
        }
        catch
        {
            if ($_ -like "*Invalid password/token*")
             {
                write-host "Password Inccorrect. Retype Password and Restart"
                return -1
                break
            }
        }
        $headers.Add($crumbs.defaultCrumbIssuer.crumbRequestField,$crumbs.defaultCrumbIssuer.crumb)
        $headers.Add("Accept", "application/xml")
        




        #Create Folder Token
        $url = "$($NODE_FOLDER)controlled-slaves/requestSubmit"
        $crumbToken = $crumbs.defaultCrumbIssuer.crumb
        
        try
        {
            $Response = Invoke-RestMethod -UseBasicParsing $url -Headers $headers -Method POST  -ContentType "application/x-www-form-urlencoded" -Body "Jenkins-Crumb:${$crumbToken}"
        }
        catch
        {
             $message = $_.ErrorDetails.Message
             $folderToken = $message.replace('%2F',"/").split("/")[-1].split("');")[0] 
              
        }
        write-host "folder token: $folderToken"

        #Create Agent Token
        $url = "$($JENKINS_URL)computer/$($NODE_NAME)/security-tokens/createSubmit"
        $Form = @{'Jenkins-Crumb'= "${crumbToken}"}
        $JSON_OBJECT = $Form | convertto-json  -Depth 5
        
        try 
        {
            $response = Invoke-RestMethod -UseBasicParsing $url -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}"
        }
        catch 
        {
            $message = $_.ErrorDetails.Message
            
            $agentToken = $message.replace('%2F',"/").split("/")[-1].split("');")[0]
            
        }
        write-host "agent token: $agentToken"

        #Get Agent Value by using Folder Token
        $url = "$($JENKINS_URL)computer/$($NODE_NAME)/security-tokens/tokensById/$($agentToken)/authorizeSubmit"
        $Form = @{"salt"= "${folderToken}"; "$redact"= "salt"; "Jenkins-Crumb"= "${crumbToken}"}
        $JSON_OBJECT = $Form | convertto-json  -Depth 5
        

        write-host "getting agent value with folder token"
        try
        {
            $response =  Invoke-RestMethod -UseBasicParsing $url -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}"
        }
        catch
        {
        }

        
        $splits =  $response -split 'value="'
        $agentValue = $splits[2].Substring(0,32)
        write-host "agent value: $agentValue"
        
        #Restrict Agent to Folder by using Agent Value
        $url = "$($NODE_FOLDER)controlled-slaves/grantsById/$($folderToken)/authorizeSubmit"
        $Form = @{"salt"= "${folderToken}"; "hash"= "${agentValue}"; "$redact"= "hash"; "Jenkins-Crumb"= "${crumbToken}"}
        $JSON_OBJECT = $Form | convertto-json  -Depth 5
        
        try
        {
            $response = Invoke-RestMethod -UseBasicParsing $url -Headers $headers -ContentType "application/x-www-form-urlencoded" -Method POST -Body "json=${JSON_OBJECT}"
        }
        catch
        {    
        }
        
        #Verify Agent is Restricted to Folder
        
        
        $url = "$($JENKINS_URL)computer/$($NODE_NAME)/security-tokens/"
        try
        {
            $response = Invoke-RestMethod -UseBasicParsing $url -Headers $headers -Method GET 
            $shortFolder = $NODE_FOLDER.Replace($JENKINS_URL, "")    
        }
        catch
        {    
        }
        
        if ($Response -like "*$shortFolder*"){
            write-host "AGENT IS RESTRICTED TO FOLDER"
        }else
        {
            write-host "AGENT IS NOT RESTRICTED TO FOLDER"
            return -1
        }
        #######################################################################
        #FINISHED #############################################################
        #######################################################################

    }-ArgumentList ($jenkinsUsername, $jenkinsPassword,$owner,$agentName,$folder,$cred)

    write-host "result is: $result"
    exit $result
}
else
{
write-host "Build agent could not reach the target server"
exit -1
}