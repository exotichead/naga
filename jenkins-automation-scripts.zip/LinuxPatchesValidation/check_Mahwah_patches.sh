#!/usr/bin/bash

for VAR in njrarlpsvr00057.linux.us.ups.com \
njrarlpsvr00058.linux.us.ups.com \
njrarlpsvr00059.linux.us.ups.com \
njrarlpsvr0005b.linux.us.ups.com \
njrarlpsvr0007a.linux.us.ups.com \
njrarlpsvr0007b.linux.us.ups.com \
njrarlpsvr0007d.linux.us.ups.com \
njrarlpsvr00095.linux.us.ups.com \
njrarlpsvr00097.linux.us.ups.com \
njrarlpsvr0005a.linux.us.ups.com \
njrarlpsvr0005c.linux.us.ups.com \
njrarlpsvr0007c.linux.us.ups.com \
njrarlpsvr0007e.linux.us.ups.com \
njrarlpsvr00096.linux.us.ups.com \
njrarlpsvr00098.linux.us.ups.com \
njrarlpsvr0096c.linux.us.ups.com \
njrarlpsvr0096d.linux.us.ups.com \
njrarlpsvr0096e.linux.us.ups.com \
njrarlpsvr0096f.linux.us.ups.com
  do echo $VAR
  ssh lzm5qvq@$VAR 'cat /etc/ansible/facts.d/patchstatus.fact; uptime; rpm -qa --last | head; echo "service status is: " ; netstat -nat | grep LISTEN | grep 8443'
done

