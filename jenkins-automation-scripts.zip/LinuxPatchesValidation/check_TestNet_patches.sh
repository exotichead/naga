#!/usr/bin/bash

for VAR in njrarltsvr000db.linux.us.ams1907.com \
njrarltsvr000dc.linux.us.ams1907.com \
njrarltsvr000dd.linux.us.ams1907.com \
njrarltsvr000de.linux.us.ams1907.com \
njrarltsvr000df.linux.us.ams1907.com \
gaalpltsvr00026.linux.us.ams1907.com \
gaalpltsvr00027.linux.us.ams1907.com \
gaalpltsvr00028.linux.us.ams1907.com \
gaalpltsvr00029.linux.us.ams1907.com \
gaalpltsvr0002a.linux.us.ams1907.com 
  do echo $VAR
  ssh lzm5qvq@$VAR 'cat /etc/ansible/facts.d/patchstatus.fact; uptime; rpm -qa --last | head; echo "service status is: " ; netstat -nat | grep LISTEN | grep 8443'
done
