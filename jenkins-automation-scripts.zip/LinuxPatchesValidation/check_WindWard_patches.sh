#!/usr/bin/bash

for VAR in gaalplpsvr00055.linux.us.ups.com \
gaalplpsvr00054.linux.us.ups.com \
gaalplpsvr0006f.linux.us.ups.com \
gaalplpsvr00056.linux.us.ups.com \
gaalplpsvr00057.linux.us.ups.com \
gaalplpsvr00058.linux.us.ups.com \
gaalplpsvr00059.linux.us.ups.com \
gaalplpsvr0006b.linux.us.ups.com \
gaalplpsvr0006c.linux.us.ups.com \
gaalplpsvr0006d.linux.us.ups.com \
gaalplpsvr0006e.linux.us.ups.com \
gaalplpsvr00085.linux.us.ups.com \
gaalplpsvr00086.linux.us.ups.com \
gaalplpsvr00087.linux.us.ups.com \
gaalplpsvr00088.linux.us.ups.com \
gaalplpapp00939.linux.us.ups.com \
gaalplpapp0093a.linux.us.ups.com \
gaalplpapp0093b.linux.us.ups.com \
gaalplpapp0093c.linux.us.ups.com
  do echo $VAR
  ssh lzm5qvq@$VAR 'cat /etc/ansible/facts.d/patchstatus.fact; uptime; rpm -qa --last | head; echo "service status is: " ; netstat -nat | grep LISTEN | grep 8443'
done

