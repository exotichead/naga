import org.acegisecurity.userdetails.UsernameNotFoundException
import com.cloudbees.hudson.plugins.folder.Folder
import com.cloudbees.hudson.plugins.folder.AbstractFolder
import com.cloudbees.hudson.plugins.folder.properties.FolderProxyGroupContainer

// https://jenkins-oc.ups.com:8443/job/MasterMaintenanceScripts/job/invalidUsers_REMOVE/

try {
    for ( folder in Jenkins.instance.getAllItems(Folder.class) ) {
        AbstractFolder < ? > abstract_folder = AbstractFolder.class.cast(folder)
        FolderProxyGroupContainer prop_fpgc = abstract_folder.getProperties().get(FolderProxyGroupContainer.class)
        
        if ( prop_fpgc != null ) {
            for ( group in prop_fpgc.getGroups() ) {
                if ( group != null ) {
                    for ( member in group.getMembers() ) {
                        // create - If true, this method will never return null for valid input (by creating a new User object if none exists.) 
                        def user = User.getById(member, true)
                        if ( user != null && member.toLowerCase() ==~ /[a-z][a-z][a-z][0-9][a-z][a-z][a-z]/ ) {
                            try {
                                // This method checks with SecurityRealm if the user is a valid user that can login to the security realm. 
                                user.impersonate()
                            } catch (UsernameNotFoundException unfe) {
                                group.doRemoveMember(member) // Remove membership
                                user.delete() // Remove the user's folder from Jenkins
                                println('Folder: ' + folder.getFullName() + ', Group: ' + group.name + ', Member : ' + member +  ' - deleted')
                            }
                        } else {
                                println('Folder: ' + folder.getFullName() + ', Group: ' + group.name + ', Member : ' + member +  ' - is null or does not have a valid ADID')
                        }
                    }
                }
            }
        }
    }
} catch (Exception e) {
    emailext body: '''Hello Jenkins Admins
                
    The scheduled job to delete stale users failed, check here: https://jenkins-oc.ups.com:8443/job/MasterMaintenanceScripts/job/invalidUsers_REMOVE/

    Regards,
    Jenkins''', subject: 'The scheduled job to delete stale users failed', to: 'mernesto@ups.com, monilpatel@ups.com, kbutryn@ups.com, sdumortier@ups.com'
}
