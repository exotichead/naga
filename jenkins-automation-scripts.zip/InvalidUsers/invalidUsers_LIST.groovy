import com.cloudbees.opscenter.server.model.*
import com.cloudbees.opscenter.server.clusterops.steps.*

// This script is meant to be run in the OC Script Console.
def matrix = [:]

// Loop over all online Client Masters
Jenkins.instance.getAllItems(ConnectedMaster.class).eachWithIndex{ it, index ->
  if (it.channel) {
    def stream = new ByteArrayOutputStream();
    def listener = new StreamBuildListener(stream);
    // Execute remote Groovy script in the Client Master
    // Result of the execution must be a String
    it.channel.call(new MasterGroovyClusterOpStep.Script("""
        import org.acegisecurity.userdetails.UsernameNotFoundException
        import com.cloudbees.hudson.plugins.folder.Folder
        import com.cloudbees.hudson.plugins.folder.AbstractFolder
        import com.cloudbees.hudson.plugins.folder.properties.FolderProxyGroupContainer

        def result = []

        for ( folder in Jenkins.instance.getAllItems(Folder.class) ) {
            AbstractFolder < ? > abstract_folder = AbstractFolder.class.cast(folder)
            FolderProxyGroupContainer prop_fpgc = abstract_folder.getProperties().get(FolderProxyGroupContainer.class)
            
            if ( prop_fpgc != null ) {
                for ( group in prop_fpgc.getGroups() ) {
                    if ( group != null ) {
                        for ( member in group.getMembers() ) {
                            // create - If true, this method will never return null for valid input (by creating a new User object if none exists.) 
                            def user = User.getById(member, true)
                            if ( user != null && member.toLowerCase() ==~ /[a-z][a-z][a-z][0-9][a-z][a-z][a-z]/ ) {
                                try {
                                    // This method checks with SecurityRealm if the user is a valid user that can login to the security realm. 
                                    user.impersonate()
                                } catch (UsernameNotFoundException unfe) {
                                    // println('Folder: ' + folder.getFullName() + ', Group: ' + group.name + ', Member : ' + member +  ' - not found')
                                    result << member
                                }
                            } else {
                                    // println('Folder: ' + folder.getFullName() + ', Group: ' + group.name + ', Member : ' + member +  ' - is null or does not have a valid ADID')
                            }
                        }
                    }
                }
            }
        }

       return result.unique().toString()
    """, listener, "host-script.groovy", [:]))

    matrix.put(it.name, stream.toString().replace('Result: ', ''))
  }
}

println('List users\n')

for (master in matrix) {
    println(master)
}
