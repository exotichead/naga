// WARNING : This Script will DELETE all the Free locakable resources from Jenkins Configuration
def count = 0;
def pluginManager = org.jenkins.plugins.lockableresources.LockableResourcesManager.get();
def lstOfLockableResources = pluginManager.getResources().findAll();
lstOfLockableResources.each(){
  print "[INFO] : Set Lockable Resource Name -> ${it.name} to be removed from Jenkins Configuration.\n"
  if (!it.locked){
    print "[FOUND] : Lockable Resource -> ${it.name}.\n";
     try {
        print "[INFO] : Trying to remove the Lockable Resource -> ${it.name}....\n";
        pluginManager.getResources().remove(it);
        count = count + 1;
        print "[SUCCESS] : Successfully removed the Lockable Resource -> ${it.name}.\n";
      } catch(Exception ex) {
        print "[ERROR] : Failed to remove the Lockable Resource -> ${it.name}.\n";
        print ex;
      }
  }
  else{
    print "[INFO | Exception] : Lockable Resource -> ${it.name} is Locked.\n"
  }
}
// Save at the end ONCE
try{
  print "[INFO] : Saving Changes in Jenkins Configuration...\n";
  pluginManager.save()
  print "[SUCCESS] : Successfully Saved Changes in Jenkins Configuration.\n";
}catch(Exception ex) {
        print "[ERROR] : Failed to save changes in Jenkins Configuration.\n";
        print ex;
}

if (count > 0){
  print "[INFO] : Successfully removed ${count} Lockable Resources.\n";
}
else{
  print "[INFO] : No Lockable Resources found.\n";
}