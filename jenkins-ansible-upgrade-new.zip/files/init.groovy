import jenkins.model.*;
// start in the state that doesn't do any build.
Jenkins.instance.doQuietDown();