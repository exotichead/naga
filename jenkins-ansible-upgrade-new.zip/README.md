# Introduction 
Ansible Documentation

# Testing Ansible Scripts
Ansible Help page
```
ansible-playbook --help
```

#Helpfull switches:
Specify ssh user to login as
```
-u <USER>
```

Ask for ssh user password on execution
```
-k
```

Ask for sudo password on execution
```
-K
```

Get more in-depth information on running tasks. Additional 'v's for more verbose logging
```
-v, -vv, -vvv
```

Specify inventory file
```
-i <INVENTORY_PATH>
```

#Running ansible playbooks
From within the root of the playbook directory
```
ansible-playbook playbook.yml
```

Example command to test against Jenkins servers
```
ansible-playbook playbook.yml -u jenkins -k -K
```

#Issues running playbooks

**Error:**
```
fatal: [<SERVER>]: FAILED! => {"msg": "Using a SSH password instead of a key is not possible because Host Key checking is enabled and sshpass does not support this.  Please add this host's fingerprint to your known_hosts file to manage this host."}
```

**Fix 1:**
Log into the target server to establish a connection

```
ssh <USER>@<SERVER>
```

Output:
```
The authenticity of host '<SERVER>' can't be established.
ECDSA key fingerprint is <FINGERPRINT>.
ECDSA key fingerprint is <FINGERPRINT>.
Are you sure you want to continue connecting (yes/no)? yes
Warning: Permanently added '<SERVER>' (ECDSA) to the list of known hosts.
```

**Fix 2:**
create ssh keys if not already created
```
ssh-keygen
```

Copy keys to target server
```
ssh-copy-id <USER>@<SERVER>
```

#Setup Proxy

``` 
export http_proxy=http://tecautomation:fol39XugZfLl@proxy.ams1907.com:8080
export https_proxy=http://tecautomation:fol39XugZfLl@proxy.ams1907.com:8080 
```

**Download rpm**
```
curl https://downloads.cloudbees.com/cje/rolling/rpm/RPMS/noarch/jenkins-2.138.4.3-1.1.noarch.rpm --output jenkins.rpm -k
```
