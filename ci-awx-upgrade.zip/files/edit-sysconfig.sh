#!/bin/bash

# The file to edit
file="/etc/sysconfig/cloudbees-core-cm"

# Text to search for
search_text="JENKINS_JAVA_OPTIONS+=(\"-Dhudson.model.DownloadService.noSignatureCheck=true\")"

# Text to add
new_text="JENKINS_JAVA_OPTIONS+=(\"-Djdk.tls.ephemeralDHKeySize=2048\")"

# Check if the file exists
if [ -e "$file" ]; then
  # Search for the text in the file
  if grep -q "$search_text" "$file"; then
    # Read the file into an array
    mapfile -t file_contents < "$file"

    # Find the line number where the search text is located
    line_number=$(grep -n "$search_text" "$file" | cut -d: -f1)

    # Add the new text right below the found line without an empty line
    file_contents=("${file_contents[@]::line_number}" "$new_text" "${file_contents[@]:line_number}")

    # Write the modified content back to the file
    printf "%s\n" "${file_contents[@]}" > "$file"

    echo "New text added successfully."
  else
    echo "Search text not found in the file."
  fi
else
  echo "File not found: $file"
fi
